package com.example.computerhunt

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: AiBridge
    private lateinit var toolBridge: ToolBridge
    private lateinit var searchBridge: SearchBridge

    // Picker used to import several model files (gguf, mmproj, ...) into the model library
    private val pickLibFiles = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> -> toolBridge.importFiles(uris) }

    // File picker used once to import the .gguf model
    private val pickModel = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) bridge.importModel(uri) else bridge.reportPickCancelled()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }

        bridge = AiBridge(this, webView) { pickModel.launch(arrayOf("*/*")) }
        webView.addJavascriptInterface(bridge, "AI")
        toolBridge = ToolBridge(this, webView) { pickLibFiles.launch(arrayOf("*/*")) }
        webView.addJavascriptInterface(toolBridge, "Tools")
        searchBridge = SearchBridge(this, webView)
        webView.addJavascriptInterface(searchBridge, "SearchBridge")

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        bridge.start()
    }

    override fun onDestroy() {
        bridge.destroy()
        toolBridge.destroy()
        searchBridge.destroy()
        webView.removeJavascriptInterface("AI")
        webView.removeJavascriptInterface("Tools")
        webView.removeJavascriptInterface("SearchBridge")
        webView.destroy()
        super.onDestroy()
    }
}

/**
 * JavaScript <-> native bridge (window.AI in the game).
 *
 *  AI.status()            -> "need_model" | "loading" | "ready"
 *  AI.pickModel()         -> opens the file picker to import a .gguf model (once)
 *  AI.chat(id, text)      -> streams tokens, then final English, then Persian
 *
 * Events to JS:
 *  window.onAiStatus({status, detail})
 *  window.onAiMessage({id, lang: "token"|"en"|"fa"|"error", text})
 */
class AiBridge(
    private val activity: AppCompatActivity,
    private val webView: WebView,
    private val launchPicker: () -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val modelFile = File(File(activity.filesDir, "models").apply { mkdirs() }, "chat.gguf")

    private var engine: InferenceEngine? = null
    @Volatile private var ready = false
    @Volatile private var busy = false
    @Volatile private var importing = false
    @Volatile private var systemPromptSet = false
    @Volatile private var sysMode = "engine"   // "engine" | "inline" | "none"
    @Volatile private var loadError = ""
    private val loadingFlag get() = File(modelFile.parentFile, "loading.flag")
    private var firstPrompt = true

    // ---------- lifecycle ----------

    fun start() {
        scope.launch {
            try {
                sysMode = try { File(modelFile.parentFile, "sysmode").readText().trim().ifEmpty { "engine" } } catch (_: Throwable) { "engine" }
                sendStatus("loading", "Starting engine")
                engine = AiChat.getInferenceEngine(activity.applicationContext)
                if (loadingFlag.exists()) {
                    // The previous start died while loading the model (unsupported or too big): do not retry automatically
                    loadingFlag.delete()
                    loadError = "The app crashed while loading this model last time (unsupported by this engine, or not enough RAM)."
                    sendStatus("need_model", loadError)
                } else if (modelFile.exists()) loadModel() else sendStatus("need_model", "")
            } catch (t: Throwable) {
                sendStatus("error", t.message ?: t::class.java.simpleName)
            }
        }
    }

    fun destroy() {
        scope.cancel()
        try { engine?.destroy() } catch (_: Throwable) {}
    }

    // ---------- model import / loading ----------

    fun reportPickCancelled() {
        if (!ready) sendStatus("need_model", "")
    }

    fun importModel(uri: Uri) {
        if (ready || importing) return
        importing = true
        scope.launch {
            try {
                sendStatus("loading", "Copying model")
                withContext(Dispatchers.IO) {
                    val tmp = File(modelFile.path + ".part")
                    activity.contentResolver.openInputStream(uri)?.use { input ->
                        tmp.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IOException("Cannot open the selected file")
                    if (modelFile.exists()) modelFile.delete()
                    tmp.renameTo(modelFile)
                    saveModelName(uri)
                }
                loadModel()
            } catch (t: Throwable) {
                sendStatus("need_model", "Import failed: ${t.message ?: t::class.java.simpleName}")
            } finally {
                importing = false
            }
        }
    }

    private suspend fun loadModel() {
        try {
            loadError = ""
            sendStatus("loading", "Loading model")
            loadingFlag.writeText("1")
            withContext(Dispatchers.IO) { engine!!.loadModel(modelFile.absolutePath) }
            // Real system prompt, kept separate from user messages (verified API: setSystemPrompt)
            systemPromptSet = if (sysMode == "engine") { try { engine!!.setSystemPrompt(SYSTEM_HINT); true } catch (t: Throwable) { false } } else false
            loadingFlag.delete()
            ready = true
            sendStatus("ready", "")
        } catch (t: Throwable) {
            // Keep the file: it may be a valid model that this engine cannot load. The user can replace it.
            loadingFlag.delete()
            loadError = t.message ?: t::class.java.simpleName
            sendStatus("need_model", "Model failed to load: $loadError")
        }
    }

    // ---------- API exposed to JavaScript ----------

    @JavascriptInterface
    fun status(): String = when {
        ready -> "ready"
        loadError.isNotEmpty() -> "need_model"
        modelFile.exists() || importing -> "loading"
        else -> "need_model"
    }

    @JavascriptInterface
    fun pickModel() {
        if (ready || importing) return
        activity.runOnUiThread { launchPicker() }
    }

    @JavascriptInterface
    fun chat(requestId: String, userText: String) = chat2(requestId, userText, 0)

    // maxTokens > 0 is passed to the engine as predictLength (real output limit)
    @JavascriptInterface
    fun chat2(requestId: String, userText: String, maxTokens: Int) {
        val eng = engine
        if (!ready || eng == null) { sendMsg(requestId, "error", "Model is not ready yet"); return }
        if (busy) { sendMsg(requestId, "error", "Still answering the previous message"); return }
        busy = true

        scope.launch {
            try {
                val prompt = if (firstPrompt && !systemPromptSet && sysMode != "none") {
                    firstPrompt = false
                    SYSTEM_HINT + "\n\n" + userText
                } else userText

                val sb = StringBuilder()
                (if (maxTokens > 0) eng.sendUserPrompt(prompt, predictLength = maxTokens) else eng.sendUserPrompt(prompt)).collect { token ->
                    sb.append(token)
                    sendMsg(requestId, "token", token)
                }
                val en = sb.toString().trim()
                sendMsg(requestId, "en", en)

                // TODO step 3: real translation with NLLB-200
                sendMsg(requestId, "fa", translateToPersian(en))
            } catch (t: Throwable) {
                sendMsg(requestId, "error", t.message ?: t::class.java.simpleName)
            } finally {
                busy = false
            }
        }
    }

    @JavascriptInterface
    fun sessionId(): String = SESSION

    @JavascriptInterface
    fun info(): String {
        val am = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val dbg = Debug.MemoryInfo()
        Debug.getMemoryInfo(dbg)
        return JSONObject()
            .put("ramTotalMb", mi.totalMem / 1048576)
            .put("ramAvailMb", mi.availMem / 1048576)
            .put("appPssMb", dbg.totalPss / 1024)
            .put("modelMb", if (modelFile.exists()) modelFile.length() / 1048576 else 0)
            .put("cores", Runtime.getRuntime().availableProcessors())
            .put("device", Build.MANUFACTURER + " " + Build.MODEL)
            .put("sdk", Build.VERSION.SDK_INT)
            .put("modelName", readModelName())
            .put("engine", "com.arm:ai-chat 0.1.0 (llama.cpp)")
            .put("systemPrompt", SYSTEM_HINT)
            .put("systemPromptSet", systemPromptSet)
            .put("sysMode", sysMode)
            .put("loadError", loadError)
            .put("ready", ready)
            .toString()
    }

    // Saves a report into the public Downloads folder (no storage permission needed on Android 10+)
    @JavascriptInterface
    fun saveReport(name: String, content: String): String {
        return try {
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.MIME_TYPE, if (safe.endsWith(".json")) "application/json" else "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val resolver = activity.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return "error:could not create file"
            resolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            "ok:$safe"
        } catch (t: Throwable) {
            "error:" + (t.message ?: t::class.java.simpleName)
        }
    }

    // Deletes the imported model so another .gguf can be chosen, then restarts the app
    @JavascriptInterface
    fun resetModel() {
        try {
            modelFile.delete()
            File(modelFile.path + ".part").delete()
            File(modelFile.parentFile, "chat.meta").delete()
            loadingFlag.delete()
        } catch (_: Throwable) {}
        restart()
    }

    // Chooses how the system prompt is given to the model, then restarts so the model reloads
    @JavascriptInterface
    fun setSysMode(mode: String) {
        if (mode != "engine" && mode != "inline" && mode != "none") return
        try { File(modelFile.parentFile, "sysmode").writeText(mode) } catch (_: Throwable) {}
        restart()
    }

    // Computes SHA-256 of the model file the engine actually loads (result via window.onAiVerify)
    @JavascriptInterface
    fun verifyModel() {
        if (!modelFile.exists()) { sendVerify(0, "", "no model file"); return }
        scope.launch(Dispatchers.IO) {
            try {
                val md = MessageDigest.getInstance("SHA-256")
                val buf = ByteArray(1 shl 20)
                var total = 0L
                modelFile.inputStream().use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        md.update(buf, 0, n)
                        total += n
                    }
                }
                sendVerify(total, md.digest().joinToString("") { "%02x".format(it) }, "")
            } catch (t: Throwable) {
                sendVerify(0, "", t.message ?: t::class.java.simpleName)
            }
        }
    }

    private fun sendVerify(bytes: Long, sha: String, err: String) {
        val json = JSONObject().put("bytes", bytes).put("sha256", sha).put("error", err)
        eval("window.onAiVerify&&window.onAiVerify(${safe(json)})")
    }

    private fun saveModelName(uri: Uri) {
        try {
            val shown = activity.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            File(modelFile.parentFile, "chat.meta").writeText(shown ?: "chat.gguf")
        } catch (_: Throwable) {}
    }

    private fun readModelName(): String =
        try { File(modelFile.parentFile, "chat.meta").readText() } catch (_: Throwable) { if (modelFile.exists()) "chat.gguf" else "" }

    // Clears the model's memory by restarting the app process (the model reloads on start)
    @JavascriptInterface
    fun restart() {
        activity.runOnUiThread {
            val i = activity.packageManager.getLaunchIntentForPackage(activity.packageName)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                activity.startActivity(i)
            }
            Runtime.getRuntime().exit(0)
        }
    }

    // ---------- placeholder, replaced by NLLB in step 3 ----------

    private fun translateToPersian(en: String): String =
        "(ترجمه‌ی فارسی در مرحله‌ی بعد اضافه می‌شود)"

    // ---------- helpers ----------

    private fun sendMsg(id: String, lang: String, text: String) {
        val json = JSONObject().put("id", id).put("lang", lang).put("text", text)
        eval("window.onAiMessage&&window.onAiMessage(${safe(json)})")
    }

    private fun sendStatus(status: String, detail: String) {
        val json = JSONObject().put("status", status).put("detail", detail)
        eval("window.onAiStatus&&window.onAiStatus(${safe(json)})")
    }

    private fun safe(j: JSONObject): String =
        j.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

    private fun eval(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    companion object {
        private const val SYSTEM_HINT =
            "You are a helpful assistant. Answer in simple English."
        private val SESSION = System.currentTimeMillis().toString()
    }
}
