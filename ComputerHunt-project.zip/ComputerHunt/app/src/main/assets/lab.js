// Model Lab: diagnostics, measured token statistics, limits, tests, exports.
// Rule: only MEASURED values are shown as numbers. Anything the engine does not expose is marked "unavailable".
window.LAB = (() => {
  'use strict';
  const st = document.createElement('style');
  st.textContent = `
  .tabs{display:flex;gap:6px;overflow-x:auto;padding-bottom:8px;margin-bottom:8px}
  .tabs button{flex:none;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:16px;padding:7px 12px;font-size:13px}
  .tabs button.on{border-color:var(--ac);color:var(--ac)}
  .bg{font-style:normal;font-size:10px;padding:2px 6px;border-radius:8px;margin-inline-start:6px;font-weight:400}
  .bg.m{background:#0f3a33;color:#5fffd8}.bg.e{background:#3a3108;color:#ffd77a}.bg.u{background:#3a1414;color:#ff9a9a}
  .note{color:var(--mut);font-size:12px;line-height:1.8;margin:8px 0}
  table.tt{width:100%;font-size:11px;border-collapse:collapse;direction:ltr;margin:6px 0}
  table.tt td,table.tt th{padding:4px 6px;border-bottom:1px solid #16292e;text-align:left;vertical-align:top}
  .pass{color:#5fffd8}.warn{color:#ffd77a}.fail{color:#ff9a9a}.skip{color:#9ab}
  input.n{width:96px;background:var(--bg);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:6px;direction:ltr}
  .tg{display:flex;gap:8px;align-items:center;justify-content:space-between;margin:10px 0;font-size:13px}
  .lbtn{margin:4px 0;width:100%}
  .chips2{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}
  .chips2 button{background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:14px;padding:7px 12px;font-size:13px;direction:ltr}
  .chips2 button.on{border-color:var(--ac);color:var(--ac);background:#0f2a2a}`;
  document.head.appendChild(st);

  // ---------- config ----------
  const DEF = { maxOut: 512, maxOutOn: true, maxConvOut: 4000, maxConvOn: false, unlimited: false };
  let cfg = Object.assign({}, DEF);
  try { Object.assign(cfg, JSON.parse(localStorage.getItem('lab_cfg') || '{}')); } catch (e) {}
  const saveCfg = () => { try { localStorage.setItem('lab_cfg', JSON.stringify(cfg)); } catch (e) {} };

  let tab = 'ov', tests = [], running = false, exportMsg = '', verify = null;
  // Official values from the Qwen/Qwen2.5-1.5B-Instruct-GGUF repository (Git LFS pointer)
  const KNOWN = { 'qwen2.5-1.5b-instruct-q4_k_m.gguf': { bytes: 1117320736, sha: '6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e' } };
  AIChat.onVerify = r => { verify = r; render(); };
  const TABS = [['ov', 'نمای کلی'], ['mod', 'مدل'], ['ti', 'بازرس توکن'], ['tok', 'آمار توکن'], ['ctx', 'کانتکست و سقف‌ها'],
    ['kv', 'KV Cache'], ['mem', 'حافظه'], ['inf', 'استنتاج'], ['test', 'تست‌ها'], ['exp', 'خروجی']];

  // ---------- helpers ----------
  const KIND = { m: 'اندازه‌گیری', e: 'تخمین', u: 'ناموجود' };
  function kvb(k, v, kind) {
    const r = h('div', 'kv'), b = h('b', null, String(v)); b.dir = 'auto';
    if (kind) b.appendChild(h('i', 'bg ' + kind, KIND[kind]));
    r.append(h('span', null, k), b); return r;
  }
  const note = t => h('div', 'note', t);
  const allAi = () => chats.flatMap(c => c.msgs).filter(m => m.role === 'ai' && m.st);
  const sessAi = () => allAi().filter(m => m.sess === SID);
  const sum = (a, f) => a.reduce((x, m) => x + f(m), 0);
  const convPieces = () => sum(cur().msgs.filter(m => m.role === 'ai' && m.st), m => m.st.tokens);
  const limitBlocks = (total, limit, on) => !!on && total >= limit;
  function quantFromName(n) { const x = /(q\d(?:_[a-z0-9]+)*|f16|f32|bf16)/i.exec(n || ''); return x ? x[1].toUpperCase() : null; }
  function sizeFromName(n) { const x = /(\d+(?:\.\d+)?)b(?![a-z])/i.exec(n || ''); return x ? x[1] + 'B' : null; }

  const api = {
    lastPrompt: '',
    maxOut: () => (!cfg.unlimited && cfg.maxOutOn) ? cfg.maxOut : 0,
    beforeSend() {
      if (!cfg.unlimited && limitBlocks(convPieces(), cfg.maxConvOut, cfg.maxConvOn))
        return 'سقف خروجی این گفتگو پر شده (' + convPieces() + ' از ' + cfg.maxConvOut + ' قطعه‌ی تولیدشده). هیچ پیامی پاک نشده. از 🧪 > «کانتکست و سقف‌ها» سقف را بالا ببر یا گفتگوی جدید شروع کن.';
      return null;
    }
  };

  // ---------- tabs ----------
  const R = {};
  R.ov = b => {
    const i = lastInfo || {};
    b.append(kvb('وضعیت مدل', status, 'm'), kvb('موتور استنتاج', i.engine || 'فقط داخل APK', i.engine ? 'm' : 'u'),
      kvb('فایل مدل', i.modelName || '—', i.modelName ? 'm' : 'u'), kvb('حجم فایل', i.modelMb != null ? i.modelMb + ' MB' : '—', i.modelMb != null ? 'm' : 'u'),
      kvb('System prompt جدا از پیام‌ها', i.systemPromptSet ? 'بله (setSystemPrompt)' : 'نه (به اولین پیام اضافه می‌شود)', i.engine ? 'm' : 'u'),
      kvb('پاسخ‌های این نشست', sessAi().length, 'm'), kvb('قطعه‌های تولیدشده در این نشست', sum(sessAi(), m => m.st.tokens), 'm'));
    b.append(note('«قطعه» = تعداد دفعاتی که موتور یک تکه‌ی متن را stream کرده است. معمولاً نزدیک به تعداد توکن است ولی شمارش واقعی توکنایزر نیست.'));
    b.append(h('h4', null, 'آخرین پرامپتی که برنامه فرستاد (قبل از قالب چت موتور)'));
    const ta = h('textarea', 'rep'); ta.readOnly = true; ta.value = api.lastPrompt || '(هنوز پیامی نفرستاده‌ای)'; b.append(ta);
  };
  R.mod = b => {
    const i = lastInfo || {}, q = quantFromName(i.modelName), sz = sizeFromName(i.modelName);
    b.append(kvb('خطای آخرین لود مدل', i.loadError || 'ندارد', i.engine ? 'm' : 'u'));
    b.append(kvb('نام فایل', i.modelName || '—', i.modelName ? 'm' : 'u'), kvb('حجم', i.modelMb != null ? i.modelMb + ' MB' : '—', i.modelMb != null ? 'm' : 'u'),
      kvb('کوانتایز (از روی نام فایل)', q || '—', q ? 'e' : 'u'), kvb('اندازه (از روی نام فایل)', sz || '—', sz ? 'e' : 'u'),
      kvb('نسخه‌ی GGUF', 'موتور نشان نمی‌دهد', 'u'), kvb('معماری', 'موتور نشان نمی‌دهد', 'u'), kvb('تعداد دقیق پارامتر', 'موتور نشان نمی‌دهد', 'u'),
      kvb('اندازه‌ی vocabulary', 'موتور نشان نمی‌دهد', 'u'), kvb('متادیتای tokenizer', 'موتور نشان نمی‌دهد', 'u'), kvb('Chat template', 'موتور خودش اعمال می‌کند؛ متنش نمایان نیست', 'u'));
    const sw = h('button', 'btn ghost lbtn', 'تعویض مدل (حذف مدل فعلی و انتخاب فایل دیگر)');
    sw.onclick = () => { closeAll(); ask('مدل فعلی از حافظه‌ی برنامه پاک می‌شود (فایل اصلی در Downloads می‌ماند) و برنامه دوباره باز می‌شود تا فایل مدل دیگری انتخاب کنی. ادامه؟', 'ادامه', () => AIChat.resetModel()); };
    b.append(sw);
    b.append(h('h4', null, 'بررسی سلامت فایل مدل'));
    const kn = KNOWN[(i.modelName || '').toLowerCase()];
    const vb = h('button', 'btn lbtn', verify === 'running' ? 'در حال محاسبه… (۱ تا ۳ دقیقه)' : 'محاسبه‌ی SHA-256 فایل مدل');
    vb.disabled = verify === 'running'; vb.onclick = () => { verify = 'running'; AIChat.verifyModel(); render(); };
    b.append(vb);
    if (verify && verify !== 'running') {
      if (verify.error) b.append(kvb('خطا', verify.error, 'u'));
      else {
        b.append(kvb('حجم دقیق (بایت)', verify.bytes, 'm'), kvb('SHA-256', verify.sha256.slice(0, 16) + '…', 'm'));
        if (kn) {
          const ok = kn.sha === verify.sha256 && kn.bytes === verify.bytes;
          b.append(kvb('مقایسه با فایل رسمی Qwen', ok ? 'سالم ✅' : 'خراب یا ناقص ❌ (دوباره دانلود کن)', 'm'));
          if (!ok) b.append(note('حجم رسمی: ' + kn.bytes + ' بایت. حجم فایل تو: ' + verify.bytes + ' بایت.'));
        } else b.append(note('هش رسمی این فایل در برنامه نیست. SHA-256 کامل: ' + verify.sha256));
      }
    }
    b.append(h('h4', null, 'روش دادن system prompt (برای عیب‌یابی خروجی درهم)'));
    const sm = h('div', 'chips2');
    [['engine', 'موتور (setSystemPrompt)'], ['inline', 'داخل پیام اول'], ['none', 'بدون system prompt']].forEach(([k, t]) => {
      const x = h('button', (i.sysMode || 'engine') === k ? 'on' : '', t);
      x.onclick = () => { if ((i.sysMode || 'engine') === k) return; closeAll(); ask('برنامه دوباره باز می‌شود تا مدل با این حالت لود شود. ادامه؟', 'ادامه', () => AIChat.setSysMode(k)); };
      sm.append(x);
    });
    b.append(sm);
    b.append(note('کتابخانه‌ی Arm ai-chat فقط loadModel / setSystemPrompt / sendUserPrompt / destroy را نشان می‌دهد. خواندن متادیتای GGUF نیاز به لایه‌ی JNI مستقیم روی llama.cpp دارد.'));
  };
  R.ti = b => {
    ['شناسه‌ی توکن‌ها (Token IDs)', 'تکه‌های رمزگشایی‌شده', 'توکن‌های ویژه', 'مقایسه‌ی encode و decode', 'تست توکنایز فارسی و انگلیسی']
      .forEach(k => b.append(kvb(k, 'موتور نشان نمی‌دهد', 'u')));
    b.append(note('برای بازرس توکن واقعی باید llama_tokenize و llama_token_to_piece را از طریق کد native در دسترس گذاشت. کتابخانه‌ی فعلی این‌ها را بیرون نمی‌دهد و من عمداً عدد ساختگی یا حدسی نشان نمی‌دهم. این بخش در مرحله‌ی بعد (لایه‌ی JNI اختصاصی) ممکن می‌شود.'));
  };
  R.tok = b => {
    const c = cur().msgs.filter(m => m.role === 'ai' && m.st), s = sessAi(), a = allAi();
    const avg = (arr, f) => arr.length ? sum(arr, f) / arr.length : 0;
    ['توکن ورودی', 'توکن system prompt', 'توکن تاریخچه'].forEach(k => b.append(kvb(k, 'بدون توکنایز قابل شمارش نیست', 'u')));
    b.append(kvb('قطعه‌های خروجی — این گفتگو', sum(c, m => m.st.tokens), 'm'), kvb('قطعه‌های خروجی — کل نشست', sum(s, m => m.st.tokens), 'm'),
      kvb('میانگین سرعت تولید', fmt(avg(a, m => m.st.tps)) + ' /s', 'm'),
      kvb('میانگین زمان تا اولین قطعه', fmt(avg(a, m => m.st.ttft)) + ' s', 'm'),
      kvb('میانگین زمان تولید', fmt(avg(a, m => m.st.total - m.st.ttft)) + ' s', 'm'));
    b.append(note('«زمان پردازش پرامپت» جدا قابل اندازه‌گیری نیست؛ زمان تا اولین قطعه شامل پردازش پرامپت + تولید اولین قطعه است.'));
    const rows = c.slice(-8);
    if (rows.length) {
      const t = h('table', 'tt'); t.innerHTML = '';
      const hd = h('tr'); ['#', 'out', 'first(s)', 'gen(s)', '/s'].forEach(x => hd.appendChild(h('th', null, x))); t.appendChild(hd);
      rows.forEach((m, k) => { const r = h('tr'); [k + 1, m.st.tokens, fmt(m.st.ttft), fmt(m.st.total - m.st.ttft), fmt(m.st.tps)].forEach(x => r.appendChild(h('td', null, String(x)))); t.appendChild(r); });
      b.append(t);
    }
  };
  R.ctx = b => {
    const outTxt = (cfg.unlimited || !cfg.maxOutOn) ? 'نامحدود (پیش‌فرض موتور)' : cfg.maxOut + ' قطعه';
    const convTxt = (cfg.unlimited || !cfg.maxConvOn) ? 'نامحدود' : cfg.maxConvOut + ' قطعه';
    b.append(kvb('سقف فعال: خروجی هر پاسخ', outTxt, 'm'), kvb('سقف فعال: خروجی کل گفتگو', convTxt, 'm'),
      kvb('طول کانتکست', 'قابل تنظیم نیست؛ موتور مشخص می‌کند', 'u'), kvb('درصد استفاده از کانتکست', 'بدون شمارش توکن قابل محاسبه نیست', 'u'));

    const m = h('div', 'tg'); m.append(h('div', null, '♾ حالت بدون محدودیت (همه‌ی سقف‌های برنامه خاموش)'));
    const mc = h('input'); mc.type = 'checkbox'; mc.checked = cfg.unlimited; mc.onchange = () => { cfg.unlimited = mc.checked; saveCfg(); render(); };
    m.append(mc); b.append(m);
    b.append(note('«نامحدود» یعنی برنامه سقفی نمی‌گذارد. سقف واقعی را همچنان موتور و پنجره‌ی کانتکست تعیین می‌کند و ممکن است تولید جایی متوقف شود یا خطا بدهد. حالت پاسخ «کوتاه» در ⚙️ یک دستور متنی جداست؛ برای جواب بلند آن را روی «عادی» بگذار.'));

    const lim = (title, key, onKey, presets, desc) => {
      const wrap = h('div'); wrap.style.opacity = cfg.unlimited ? '.45' : '1';
      wrap.append(h('h4', null, title), note(desc));
      const row = h('div', 'chips2');
      presets.forEach(p => {
        const x = h('button', (cfg[onKey] && cfg[key] === p) ? 'on' : '', String(p));
        x.onclick = () => { cfg[key] = p; cfg[onKey] = true; saveCfg(); render(); }; row.append(x);
      });
      const inf = h('button', !cfg[onKey] ? 'on' : '', '∞ نامحدود');
      inf.onclick = () => { cfg[onKey] = false; saveCfg(); render(); }; row.append(inf);
      wrap.append(row);
      const cr = h('div', 'tg'); cr.append(h('span', null, 'مقدار دلخواه'));
      const inp = h('input', 'n'); inp.type = 'number'; inp.min = '1'; inp.value = cfg[key];
      inp.onchange = () => { const v = parseInt(inp.value); if (v > 0) { cfg[key] = v; cfg[onKey] = true; saveCfg(); render(); } };
      cr.append(inp); wrap.append(cr); b.append(wrap);
    };
    lim('B) حداکثر خروجی هر پاسخ (قطعه)', 'maxOut', 'maxOutOn', [64, 128, 256, 512, 1024, 2048, 4096],
      'به موتور داده می‌شود (اعمال واقعی). نامحدود = بدون predictLength، یعنی پیش‌فرض داخلی موتور.');
    lim('C) حداکثر خروجی کل گفتگو (قطعه)', 'maxConvOut', 'maxConvOn', [1000, 2000, 4000, 8000, 16000, 32000],
      'قبل از ارسال چک می‌شود. چیزی پاک نمی‌شود؛ فقط ارسال مسدود و هشدار داده می‌شود.');

    b.append(h('h4', null, 'ناموجود'), kvb('A) سقف توکن ورودی هر درخواست', 'بدون توکنایز قابل اعمال نیست', 'u'), kvb('D) سقف توکن تاریخچه', 'بدون توکنایز قابل اعمال نیست', 'u'));
    if (cfg.maxConvOn && !cfg.unlimited) {
      const used = convPieces(), pct = Math.min(100, used / cfg.maxConvOut * 100);
      b.append(h('h4', null, 'بودجه‌ی خروجی این گفتگو'), kvb('مصرف', used + ' / ' + cfg.maxConvOut + ' (' + fmt(pct) + '%)', 'm'));
      const bar = h('div', 'bar' + (pct > 85 ? ' warn' : '')); const f = document.createElement('i'); f.style.width = pct + '%'; bar.append(f); b.append(bar);
    }
  };
  R.kv = b => {
    ['نوع KV Cache', 'حافظه‌ی مصرفی KV', 'ظرفیت KV', 'اشغال فعلی کانتکست'].forEach(k => b.append(kvb(k, 'موتور نشان نمی‌دهد', 'u')));
    const i = lastInfo || {};
    if (i.modelName && /1\.5b/i.test(i.modelName) && /qwen2\.5/i.test(i.modelName)) {
      const per = 2 * 28 * 2 * 128 * 2; // K+V x layers x kv_heads x head_dim x bytes(FP16)
      b.append(h('h4', null, 'تخمین نظری'), kvb('هر توکن (FP16)', fmt(per / 1024) + ' KB', 'e'), kvb('برای ۴۰۹۶ توکن', fmt(per * 4096 / 1048576, 0) + ' MB', 'e'));
      b.append(note('این تخمین فقط از ساختار شناخته‌شده‌ی Qwen2.5-1.5B (۲۸ لایه، ۲ هد KV، head=128) و فرض FP16 و کانتکست ۴۰۹۶ است. کانتکست و نوع KV واقعی موتور معلوم نیست.'));
    }
    b.append(note('حافظه‌ی KV با وزن‌های مدل و رم کل برنامه فرق دارد. رم کل برنامه در نوار بالای صفحه (اندازه‌گیری‌شده) است.'));
  };
  R.mem = b => {
    const s = sessAi(), ex = sessAi().length;
    b.append(kvb('تبادل‌های ذخیره‌شده در حافظه‌ی موتور (از شروع این نشست)', ex, 'm'));
    b.append(note('موتور خودش تاریخچه را نگه می‌دارد و هر پیام جدید را به همان اضافه می‌کند؛ برنامه تاریخچه را دوباره نمی‌فرستد (تکراری می‌شد). مدل فقط چیزی را می‌داند که در همین نشست به آن گفته‌ای. پاک کردن حافظه‌ی مدل فقط با راه‌اندازی مجدد برنامه ممکن است. خلاصه‌سازی خودکار هنوز پیاده نشده.'));
    const b1 = h('button', 'btn ghost lbtn', 'پاک کردن حافظه‌ی مدل (راه‌اندازی مجدد)');
    b1.onclick = () => { closeAll(); ask('برنامه دوباره باز می‌شود و حافظه‌ی مدل پاک می‌شود. گفتگوهای ذخیره‌شده می‌مانند. ادامه؟', 'ادامه', () => { localStorage.setItem('pendingNew', '1'); save(); AIChat.restart(); }); };
    const b2 = h('button', 'btn ghost lbtn', 'خروجی گرفتن از این گفتگو (شامل متن پیام‌ها)');
    b2.onclick = () => { const c = cur(); exportMsg = AIChat.save('conversation_export.json', JSON.stringify({ messages: c.msgs.map(m => ({ role: m.role, text: m.role === 'user' ? m.text : (m.raw || '') })) }, null, 2)); render(); };
    b.append(b1, b2, note(exportMsg));
  };
  R.inf = b => {
    const i = lastInfo || {}, last = allAi().slice(-1)[0];
    ['Temperature', 'Top-P', 'Top-K', 'Repetition penalty'].forEach(k => b.append(kvb(k, 'موتور نشان نمی‌دهد (پیش‌فرض داخلی)', 'u')));
    b.append(kvb('تعداد هسته‌های CPU دستگاه', i.cores != null ? i.cores : '—', i.cores != null ? 'm' : 'u'), kvb('تعداد thread مصرفی موتور', 'نامشخص', 'u'),
      kvb('سقف خروجی ارسالی به موتور', cfg.maxOutOn ? cfg.maxOut : 'پیش‌فرض موتور', 'm'));
    if (last) b.append(kvb('آخرین پاسخ: سرعت', fmt(last.st.tps) + ' /s', 'm'), kvb('آخرین پاسخ: قطعه‌ها', last.st.tokens, 'm'), kvb('آخرین پاسخ: زمان کل', fmt(last.st.total) + ' s', 'm'));
  };

  // ---------- tests ----------
  const ask1 = (prompt, maxTokens) => new Promise(res => {
    const t0 = performance.now(); let tf = 0, n = 0, out = '', done = false;
    const fin = o => { if (!done) { done = true; res(Object.assign({ pieces: n, ms: performance.now() - t0 }, o)); } };
    setTimeout(() => fin({ out, err: 'timeout 180s' }), 180000);
    AIChat.send(prompt, en => { out = en; }, () => fin({ out }), () => { if (!tf) tf = performance.now(); n++; }, e => fin({ out, err: e }), { maxTokens: maxTokens || 0 });
  });
  const latinRatio = s => { const L = s.match(/\p{L}/gu) || [], A = s.match(/[A-Za-z]/g) || []; return L.length ? A.length / L.length : 0; };
  const single = (name, prompt, check, maxTokens) => async () => {
    const r = await ask1(prompt, maxTokens);
    return { name, input: prompt, output: r.out || r.err || '', pieces: r.pieces, ms: r.ms, status: r.err ? 'FAIL' : check(r.out, r) };
  };
  const TESTS = [
    single('1 Reply exactly HELLO', 'Reply exactly: HELLO', o => o.trim().replace(/[.!]+$/, '') === 'HELLO' ? 'PASS' : (/hello/i.test(o) ? 'WARN' : 'FAIL')),
    single('2 Reply in English', 'Say good morning and ask how I am.', o => latinRatio(o) >= 0.9 ? 'PASS' : 'FAIL'),
    single('3 Reply in Persian', 'Reply in Persian: say hello and ask how I am.', o => ((o.match(/[\u0600-\u06FF]/g) || []).length >= 5) ? 'PASS' : 'FAIL'),
    single('4 Count 1 to 5', 'Count from 1 to 5.', o => /1\D+2\D+3\D+4\D+5/.test(o) ? 'PASS' : 'FAIL'),
    async () => {
      const a = await ask1('Remember this: my favorite color is blue. Reply OK.');
      const r = await ask1('What is my favorite color? Answer in one word.');
      return { name: '5 Remember a fact', input: 'fact -> question', output: r.out || r.err || '', pieces: a.pieces + r.pieces, ms: a.ms + r.ms, status: r.err ? 'FAIL' : (/blue/i.test(r.out) ? 'PASS' : 'FAIL') };
    },
    async () => {
      const ws = ['alpha', 'bravo', 'charlie', 'delta']; let ms = 0, pieces = 0, last = null;
      for (let k = 0; k < ws.length; k++) { last = await ask1('Fact ' + (k + 1) + ': the code word is ' + ws[k] + '. Reply OK.'); ms += last.ms; pieces += last.pieces; }
      const r = await ask1('What was the code word in Fact 2? One word.'); ms += r.ms; pieces += r.pieces;
      return { name: '6 Longer conversation', input: '4 facts -> recall fact 2', output: r.out || r.err || '', pieces, ms, status: r.err ? 'FAIL' : (/bravo/i.test(r.out) ? 'PASS' : 'FAIL') };
    },
    async () => {
      const ok = limitBlocks(10, 5, true) && !limitBlocks(3, 5, true) && !limitBlocks(10, 5, false);
      return { name: '7 Conversation limit enforcement', input: 'app-side logic (no model call)', output: 'engine context limit cannot be tested: no API', pieces: 0, ms: 0, status: ok ? 'PASS' : 'FAIL' };
    },
    single('8 Output limit (max 20)', 'Count from 1 to 100, separated by commas.', (o, r) => r.pieces <= 25 ? 'PASS' : 'FAIL', 20),
    async () => ({ name: '9 Token counting accuracy', input: '-', output: 'SKIPPED: no tokenizer API exposed by the engine', pieces: 0, ms: 0, status: 'SKIPPED' })
  ];
  async function runTests() {
    if (running || busy || status !== 'ready') return;
    running = true; busy = true; UI.setBusy(busy); tests = []; render();
    for (const t of TESTS) {
      try { tests.push(await t()); } catch (e) { tests.push({ name: '?', input: '', output: String(e), pieces: 0, ms: 0, status: 'FAIL' }); }
      render();
    }
    running = false; busy = false; UI.setBusy(busy); render();
  }
  R.test = b => {
    b.append(note('تست‌ها واقعاً مدل را صدا می‌زنند و پیام‌هایشان وارد حافظه‌ی مدل این نشست می‌شود. بعد از تست، «پاک کردن حافظه‌ی مدل» را بزن. ممکن است چند دقیقه طول بکشد.'));
    const go = h('button', 'btn lbtn', running ? 'در حال اجرا… (' + tests.length + '/' + TESTS.length + ')' : 'اجرای همه‌ی تست‌ها');
    go.disabled = running || busy || status !== 'ready'; go.onclick = runTests; b.append(go);
    if (tests.length) {
      const t = h('table', 'tt'); const hd = h('tr'); ['test', 'out', 'ms', 'status'].forEach(x => hd.appendChild(h('th', null, x))); t.appendChild(hd);
      tests.forEach(r => {
        const tr = h('tr'); tr.append(h('td', null, r.name), h('td', null, (r.output || '').slice(0, 60).replace(/\s+/g, ' ') + ' [' + r.pieces + ']'), h('td', null, String(Math.round(r.ms))),
          h('td', r.status === 'PASS' ? 'pass' : r.status === 'WARN' ? 'warn' : r.status === 'FAIL' ? 'fail' : 'skip', r.status)); t.appendChild(tr);
      });
      b.append(t);
    }
  };

  // ---------- exports ----------
  function build() {
    const i = lastInfo || {}, a = allAi();
    const diag = {
      generated: new Date().toISOString(), app: 'Offline AI Test',
      device: { model: i.device, sdk: i.sdk, cores: i.cores, ramTotalMb: i.ramTotalMb, ramAvailMb: i.ramAvailMb, appPssMb: i.appPssMb },
      model: { fileName: i.modelName, sizeMb: i.modelMb, quantizationFromFileName: quantFromName(i.modelName) },
      engine: i.engine, systemPromptMode: i.sysMode, modelIntegrity: (verify && verify !== 'running') ? { bytes: verify.bytes, sha256: verify.sha256, error: verify.error || null } : null, systemPromptSeparate: !!i.systemPromptSet, systemPrompt: i.systemPrompt,
      limits: cfg,
      unavailableFromEngine: ['GGUF version', 'architecture', 'parameter count', 'vocab size', 'tokenizer metadata', 'chat template text', 'token IDs', 'input/history token counts', 'KV cache stats', 'context length', 'sampling settings', 'thread count'],
      tests: tests.map(t => ({ name: t.name, input: t.input, output: t.output, pieces: t.pieces, ms: Math.round(t.ms), status: t.status }))
    };
    const usage = { note: 'pieces = streamed output chunks measured by the app (not tokenizer counts)',
      requests: a.map(m => ({ mode: m.mode, maxOut: m.maxOut || null, pieces: m.st.tokens, firstPieceSec: +fmt(m.st.ttft, 2), totalSec: +fmt(m.st.total, 2), piecesPerSec: +fmt(m.st.tps, 2), thinkSec: m.st.think })) };
    const conv = { conversations: chats.map(c => { const ai = c.msgs.filter(m => m.role === 'ai' && m.st);
      return { userMessages: c.msgs.filter(m => m.role === 'user').length, aiMessages: ai.length, outputPieces: sum(ai, m => m.st.tokens), avgPiecesPerSec: ai.length ? +fmt(sum(ai, m => m.st.tps) / ai.length, 2) : 0 }; }) };
    const txt = ['Offline AI Test diagnostics', 'Generated: ' + diag.generated, 'Device: ' + [i.device, 'SDK ' + i.sdk, i.cores + ' cores'].join(' | '),
      'RAM: total ' + i.ramTotalMb + ' MB, avail ' + i.ramAvailMb + ' MB, app ' + i.appPssMb + ' MB',
      'Model: ' + i.modelName + ' (' + i.modelMb + ' MB), quant (from filename): ' + quantFromName(i.modelName), 'Engine: ' + i.engine,
      'Responses: ' + a.length + ' | output pieces ' + sum(a, m => m.st.tokens),
      'Unavailable from engine: ' + diag.unavailableFromEngine.join(', '), '', 'Tests:']
      .concat(tests.map(t => t.status + ' | ' + t.name + ' | pieces ' + t.pieces + ' | ' + Math.round(t.ms) + ' ms')).join('\n');
    return { 'diagnostics.json': JSON.stringify(diag, null, 2), 'diagnostics.txt': txt, 'token_usage.json': JSON.stringify(usage, null, 2), 'conversation_statistics.json': JSON.stringify(conv, null, 2) };
  }
  R.exp = b => {
    b.append(note('گزارش‌ها در پوشه‌ی Downloads ذخیره می‌شوند. فقط آمار و تنظیمات هستند؛ متن پیام‌ها و عنوان گفتگوها داخلشان نیست و مدل GGUF هم داخلشان نیست.'));
    const all = h('button', 'btn lbtn', 'ذخیره‌ی هر ۴ گزارش'); all.onclick = () => { pollInfo(); const f = build(); exportMsg = Object.keys(f).map(k => AIChat.save(k, f[k])).join(' | '); render(); };
    b.append(all);
    Object.keys(build()).forEach(k => { const x = h('button', 'btn ghost lbtn', k); x.onclick = () => { exportMsg = AIChat.save(k, build()[k]); render(); }; b.append(x); });
    b.append(note(exportMsg));
    const ta = h('textarea', 'rep'); ta.readOnly = true; ta.value = build()['diagnostics.txt']; ta.onclick = () => ta.select(); b.append(h('h4', null, 'پیش‌نمایش diagnostics.txt'), ta);
  };

  // ---------- render ----------
  function render() {
    const tabs = $('#lab-tabs'); tabs.textContent = '';
    TABS.forEach(([k, t]) => { const x = h('button', k === tab ? 'on' : '', t); x.onclick = () => { tab = k; render(); }; tabs.appendChild(x); });
    const body = $('#lab-body'); const y = body.parentElement.scrollTop; body.textContent = ''; R[tab](body); body.parentElement.scrollTop = y;
  }
  $('#blab').onclick = () => { pollInfo(); render(); openPanel('#sheet-lab'); };
  return api;
})();
