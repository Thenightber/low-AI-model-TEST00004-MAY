// Image Studio UI: models, roles, create (loop / manual / direct), gallery, experiments, web search.
(() => {
  'use strict';
  const C = StudioCore;
  const ld = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const mb = b => !b ? '—' : (b >= 1073741824 ? fmt(b / 1073741824, 2) + ' GB' : Math.round(b / 1048576) + ' MB');
  const tools = (typeof window.Tools !== 'undefined') ? C.nativeTools(window.Tools) : C.mockTools();

  const st = document.createElement('style');
  st.textContent = `
  .card2{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:12px;margin:10px 0}
  .mt{font-weight:700;font-size:15px;margin-bottom:4px}
  .chip{display:inline-block;font-size:11px;padding:2px 8px;border-radius:10px;background:#0f2a2a;color:#5fffd8;margin:2px 0 2px 4px;direction:ltr}
  .chip.bad{background:#3a1414;color:#ff9a9a}.chip.warn{background:#3a3108;color:#ffd77a}.chip.dim{background:#16292e;color:var(--mut)}
  .frow{display:flex;justify-content:space-between;gap:8px;align-items:center;font-size:12px;padding:5px 0;border-bottom:1px solid #16292e;direction:ltr}
  .frow span{overflow:hidden;text-overflow:ellipsis}
  .tl .ph{font-size:12px;padding:3px 0;direction:ltr;text-align:left}
  .ph.run{color:#ffd77a}.ph.done{color:#5fffd8}.ph.error{color:#ff9a9a}
  .rimg{width:100%;max-width:320px;border-radius:10px;border:1px solid var(--line);display:block;margin:8px 0;cursor:zoom-in}
  .in{width:100%;background:var(--bg);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:9px;font-size:14px;font-family:inherit}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:8px 0}
  .grid2 label{font-size:12px;color:var(--mut);display:block;margin-bottom:2px}
  .sbtn{background:none;border:1px solid var(--line);color:var(--tx);border-radius:8px;padding:6px 10px;font-size:12px;margin:2px 0 2px 6px}
  .pre{white-space:pre-wrap;direction:ltr;text-align:left;font-size:12px;color:#9cc;line-height:1.55}
  .seg2{display:flex;gap:6px;margin:8px 0}
  .seg2 button{flex:1;background:var(--panel2);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:9px 4px;font-size:13px}
  .seg2 button.on{border-color:var(--ac);color:var(--ac);background:#0f2a2a}
  .gal{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .gcard{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:8px}
  .gcard img{width:100%;border-radius:8px;display:block;cursor:zoom-in;background:#000}
  .gph{height:120px;border-radius:8px;background:#0b1418;color:var(--mut);display:flex;align-items:center;justify-content:center;font-size:12px}
  .gcard .t{font-size:11px;color:var(--mut);direction:ltr;text-align:left;margin:6px 0;line-height:1.4;max-height:3.2em;overflow:hidden}
  #st-viewer{position:fixed;inset:0;background:#000e;z-index:40;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px;gap:10px;overflow:auto}
  #st-viewer img{max-width:100%;max-height:62dvh;border-radius:10px}
  #st-viewer .cap{max-width:420px;font-size:12px;color:#cde;direction:ltr;text-align:left;line-height:1.6}`;
  document.head.appendChild(st);

  // ---------- state ----------
  let tab = 'models', rt = null, lib = {}, reqText = ld('studio_req', ''), promptText = ld('studio_prompt', ''), mode = ld('studio_mode', 'loop');
  let custom = ld('studio_custom', []);
  let roles = Object.assign({ supervisor: '', generator: '', critic: '', editor: '' }, ld('studio_roles', {}));
  let runs = ld('studio_runs', []), tests = ld('studio_tests', []), gallery = ld('studio_gallery', []);
  const savedCfg = ld('studio_cfg', {});
  let cfg = Object.assign(JSON.parse(JSON.stringify(C.DEFAULTS)), savedCfg);
  cfg.extra = Object.assign({}, C.DEFAULTS.extra, savedCfg.extra || {});
  cfg.gen = Object.assign({}, C.DEFAULTS.gen, savedCfg.gen || {});
  let running = false, stopFlag = false, view = null, runArea = null, testBusy = false, pendingReview = null;
  const impMsg = {}, linkOpen = {};
  let showForm = false;

  const seatsOf = () => Object.fromEntries(Object.keys(roles).map(k => [k, roles[k] ? ((C.CATALOG.concat(custom).find(m => m.id === roles[k]) || {}).name || roles[k]) : '']));
  const models = () => C.CATALOG.concat(custom);
  const getModel = id => models().find(m => m.id === id);
  function refresh() {
    try { rt = tools.runtime(); } catch (e) { rt = null; }
    lib = {};
    try { tools.lib().forEach(x => { lib[x.id] = x.files; }); } catch (e) {}
  }
  const saveCfg = () => sv('studio_cfg', cfg);
  const note = (t, cls) => h('div', 'note' + (cls ? ' ' + cls : ''), t);
  const chip = (t, cls) => h('span', 'chip' + (cls ? ' ' + cls : ''), t);
  const msg = t => ask(t, 'باشه', null);
  const ptxt = p => p ? (p.size + '×' + p.size + ' · steps ' + p.steps + ' · cfg ' + p.cfg + ' · ' + p.sampler) : '';

  tools.onLib(ev => {
    if (ev.type === 'progress') impMsg[ev.modelId] = 'در حال کپی ' + ev.file + ' — ' + mb(ev.bytes);
    else if (ev.type === 'file_done') impMsg[ev.modelId] = ev.file + ' ✅ (' + mb(ev.bytes) + ')';
    else if (ev.type === 'error') impMsg[ev.modelId] = 'خطا: ' + (ev.msg || ev.file);
    else if (ev.type === 'done') { impMsg[ev.modelId] = 'کپی تمام شد'; refresh(); }
    render();
  });

  // ---------- image viewer + saving ----------
  async function openViewer(item) {
    const old = document.getElementById('st-viewer'); if (old) old.remove();
    const v = h('div'); v.id = 'st-viewer';
    const img = document.createElement('img'); img.src = item.thumb || item.dataUrl || '';
    const cap = h('div', 'cap', (item.prompt || '') + '\n' + (item.model || '') + ' · seed ' + (item.seed != null ? item.seed : '?') + ' · ' + ptxt(item.params));
    cap.style.whiteSpace = 'pre-wrap';
    const row = h('div');
    const sp = h('button', 'btn', 'ذخیره PNG'); sp.onclick = () => msg(saveResult(item));
    const si = h('button', 'btn ghost', 'ذخیره با اطلاعات (JSON)'); si.onclick = () => msg(saveInfo(item));
    const cl = h('button', 'btn ghost', 'بستن'); cl.onclick = () => v.remove();
    row.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;justify-content:center';
    row.append(sp, si, cl); v.append(img, cap, row); document.body.append(v);
    if (item.path) {
      const full = await tools.readImage(item.path);
      if (String(full).startsWith('data:')) img.src = full;
      else if (!item.dataUrl) cap.append(document.createTextNode('\n(فایل اصلی دیگر موجود نیست؛ نسخه‌ی کوچک نمایش داده می‌شود)'));
    }
  }
  function saveResult(item) {
    if (!item.path) return 'مسیر تصویر نامشخص است';
    const r = tools.saveImage(item.path, 'studio_' + (item.ts || Date.now()) + '_' + (item.seed != null ? item.seed : 0) + '.png');
    return String(r).startsWith('ok') ? 'ذخیره شد: ' + String(r).slice(3) : 'خطا: ' + r + ' (شاید فایل پاک شده)';
  }
  function saveInfo(item) {
    const info = { prompt: item.prompt, request: item.request, model: item.model, seed: item.seed, params: item.params, mode: item.mode, score: item.score, created: new Date(item.ts || Date.now()).toISOString() };
    return 'نتیجه: ' + AIChat.save('studio_' + (item.ts || Date.now()) + '_' + (item.seed != null ? item.seed : 0) + '.json', JSON.stringify(info, null, 2));
  }
  function makeThumb(url) {
    return new Promise(res => {
      try {
        const im = new Image();
        im.onload = () => { const s = 160 / Math.max(im.width, im.height, 1), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * s)); c.height = Math.max(1, Math.round(im.height * s)); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.6)); };
        im.onerror = () => res(null); im.src = url;
      } catch (e) { res(null); }
    });
  }
  async function addToGallery(run) {
    const outs = run.mode === 'direct' ? run.outputs : run.outputs.filter(o => run.final && o.path === run.final.path);
    for (const o of outs) {
      const im = view && view.images[o.round], thumb = im ? await makeThumb(im.dataUrl) : null;
      gallery.unshift({ id: 'g' + Date.now() + Math.random().toString(36).slice(2, 6), ts: run.ts, request: run.request, mode: run.mode, status: run.status, prompt: o.prompt, seed: o.seed, params: o.params, model: o.model,
        path: o.path, score: run.final && run.final.path === o.path ? run.final.score : null, thumb });
    }
    gallery = gallery.slice(0, 40); sv('studio_gallery', gallery);
  }

  // ---------- Models tab ----------
  const R = {};
  function modelCard(m) {
    const card = h('div', 'card2'), listing = lib[m.id] || [], fs = C.fileStatus(m, listing);
    card.append(h('div', 'mt', m.name));
    card.append(note('runtime: ' + m.runtime + (m.family ? ' · ' + C.FAMILIES[m.family].title : '') + (m.license ? ' · ' + m.license : '') + (m.note ? ' · ' + m.note : '')));
    const caps = h('div'); (m.caps || []).forEach(c => caps.append(chip(C.CAPS[c] || c))); card.append(caps);
    const can = h('div');
    Object.keys(C.ROLES).forEach(role => { if (C.eligible(m, role, listing).ok) can.append(chip('✅ ' + C.ROLES[role].title)); });
    if (!can.childNodes.length) can.append(chip('هنوز برای هیچ نقشی آماده نیست', 'warn'));
    card.append(can);
    Object.values(fs).forEach(f => {
      const decl = (m.files || []).find(x => x.key === f.key);
      const row = h('div', 'frow');
      row.append(h('span', null, (f.ok ? '✅ ' : f.have ? '⚠️ ' : '❌ ') + f.name + '  ' + (f.have ? mb(f.bytes) : (f.expected ? '(' + mb(f.expected) + ')' : ''))));
      if (decl && decl.url) { const b = h('button', 'sbtn', 'لینک'); b.onclick = () => { linkOpen[m.id + f.key] = !linkOpen[m.id + f.key]; render(); }; row.append(b); }
      card.append(row);
      if (decl && decl.url && linkOpen[m.id + f.key]) {
        const inp = h('input', 'in'); inp.readOnly = true; inp.value = decl.url; inp.style.direction = 'ltr'; inp.onclick = () => inp.select();
        const ob = h('button', 'sbtn', 'باز کردن در مرورگر'); ob.onclick = () => tools.openUrl(decl.url);
        card.append(inp, ob);
        if (decl.sha) card.append(h('div', 'note', 'SHA-256 مرجع: ' + decl.sha));
      }
    });
    if (m.page) { const pb = h('button', 'sbtn', 'صفحه‌ی مدل در مرورگر'); pb.onclick = () => tools.openUrl(m.page); card.append(pb); }
    card.append(note('رم تقریبی هنگام اجرا: ' + C.estimateRamMb(m, listing) + ' MB'));
    if (impMsg[m.id]) card.append(note(impMsg[m.id]));
    const row = h('div'); row.style.cssText = 'display:flex;gap:8px;margin-top:8px;flex-wrap:wrap';
    const add = h('button', 'btn ghost', 'افزودن فایل‌ها'); add.onclick = () => { impMsg[m.id] = 'منتظر انتخاب فایل…'; tools.libImport(m.id); render(); };
    const del = h('button', 'btn ghost', 'حذف فایل‌ها'); del.onclick = () => ask('فایل‌های «' + m.name + '» از حافظه‌ی برنامه پاک شوند؟', 'حذف', () => { tools.libDelete(m.id); refresh(); render(); });
    row.append(add, del);
    if (m.custom) { const rm = h('button', 'btn ghost', 'حذف مدل'); rm.onclick = () => { custom = custom.filter(x => x.id !== m.id); sv('studio_custom', custom); tools.libDelete(m.id); refresh(); render(); }; row.append(rm); }
    card.append(row);
    return card;
  }
  function customForm() {
    const box = h('div', 'card2');
    if (!showForm) { const b = h('button', 'btn ghost', '＋ مدل دلخواه (متنی، بینا یا تصویری)'); b.onclick = () => { showForm = true; render(); }; box.append(b); return box; }
    box.append(h('div', 'mt', 'مدل دلخواه'));
    const name = h('input', 'in'); name.placeholder = 'نام مدل';
    const rtSel = h('select', 'in'); Object.keys(C.RUNTIMES).forEach(k => rtSel.append(new Option(k + ' — ' + C.RUNTIMES[k].tool, k)));
    const famSel = h('select', 'in'); Object.keys(C.FAMILIES).forEach(k => famSel.append(new Option(C.FAMILIES[k].title + ' — ' + C.FAMILIES[k].note, k)));
    const capBox = h('div'), checks = {};
    const draw = () => {
      capBox.textContent = ''; famSel.style.display = rtSel.value === 'sd' ? '' : 'none';
      C.RUNTIMES[rtSel.value].allowed.forEach(c => { const l = h('label'); l.style.cssText = 'display:inline-block;margin:4px 10px 4px 0;font-size:13px'; const cb = h('input'); cb.type = 'checkbox'; cb.checked = rtSel.value === 'sd'; checks[c] = cb; l.append(cb, document.createTextNode(' ' + C.CAPS[c])); capBox.append(l); });
    };
    rtSel.onchange = draw; draw();
    box.append(name, rtSel, famSel, capBox, note('برای مدل تصویری، «خانواده» مقدارهای پیش‌فرض (steps، cfg، sampler، اندازه) را تعیین می‌کند. قابلیت‌ها را خودت اعلام می‌کنی؛ سیستم سازگاری با runtime و وجود فایل‌ها را چک می‌کند. برای مدل بینا فایل mmproj لازم است.'));
    const ok = h('button', 'btn', 'ذخیره'); ok.onclick = () => {
      const caps = Object.keys(checks).filter(c => checks[c].checked);
      const m = { id: 'c_' + Date.now().toString(36), name: name.value.trim() || 'مدل دلخواه', runtime: rtSel.value, template: 'chatml', caps, custom: true, files: [] };
      if (rtSel.value === 'sd') m.family = famSel.value;
      const errs = C.validateModelDef(m); if (errs.length || !caps.length) { msg(errs.join('\n') || 'حداقل یک قابلیت انتخاب کن'); return; }
      custom.push(m); sv('studio_custom', custom); showForm = false; render();
    };
    const cancel = h('button', 'btn ghost', 'انصراف'); cancel.onclick = () => { showForm = false; render(); };
    const r = h('div'); r.style.cssText = 'display:flex;gap:8px;margin-top:8px'; r.append(ok, cancel); box.append(r);
    return box;
  }
  R.models = b => {
    const c = h('div', 'card2');
    if (!tools.native) c.append(note('🧪 حالت نمایشی مرورگر: ابزارها و فایل‌ها شبیه‌سازی شده‌اند و جواب‌ها ساختگی‌اند.', 'warn'));
    if (rt) {
      Object.entries(rt.tools).forEach(([n, t]) => { const r = h('div', 'frow'); r.append(h('span', null, n), h('span', null, t.exists ? '✅ ' + mb(t.bytes) : '❌ در APK نیست')); c.append(r); });
      if (!Object.values(rt.tools).every(t => t.exists)) c.append(note('بعضی ابزارها در APK نیستند: ساخت job «tools» در GitHub Actions را چک کن.', 'warn'));
    } else c.append(note('وضعیت ابزارها خوانده نشد.'));
    b.append(c);
    models().forEach(m => b.append(modelCard(m)));
    b.append(customForm());
  };

  // ---------- Roles tab ----------
  R.roles = b => {
    b.append(note('حالت فعلی: «' + C.MODES[mode].title + '» — نقش‌های لازم: ' + C.MODES[mode].roles.map(r => C.ROLES[r].title).join('، ') + (mode === 'direct' ? '' : ' (ویرایشگر اختیاری)')));
    b.append(note('هر نقش فقط مدل‌هایی را آماده نشان می‌دهد که قابلیت لازم و فایل‌های کامل را دارند؛ بقیه خاکستری و با دلیل نمایش داده می‌شوند.'));
    Object.keys(C.ROLES).forEach(role => {
      const box = h('div', 'card2'); box.append(h('div', 'mt', C.ROLES[role].title + (C.ROLES[role].optional ? ' (اختیاری)' : '')));
      box.append(note('نیاز: ' + C.ROLES[role].need.map(c => C.CAPS[c]).join(' + ')));
      const sel = h('select', 'in');
      sel.append(new Option(C.ROLES[role].optional ? '— بدون ' + C.ROLES[role].title + ' —' : '— انتخاب کن —', ''));
      models().forEach(m => {
        const e = C.eligible(m, role, lib[m.id]);
        const o = new Option(e.ok ? m.name : '⛔ ' + m.name + ' — ' + e.reasons[0], m.id); o.disabled = !e.ok; sel.append(o);
      });
      sel.value = roles[role] || '';
      sel.onchange = () => { roles[role] = sel.value; sv('studio_roles', roles); UI.studio.setSeats(seatsOf()); render(); };
      box.append(sel); b.append(box);
    });
    const v = C.validateRoles(roles, models(), lib, mode), res = h('div', 'card2');
    v.errors.forEach(e => res.append(h('div', 'note fail', '⛔ ' + e)));
    v.info.forEach(e => res.append(h('div', 'note', 'ℹ️ ' + e)));
    if (v.ok) res.append(h('div', 'note pass', '✅ ترکیب نقش‌ها معتبر است.'));
    b.append(res);
  };

  // ---------- Create tab ----------
  const genModel = () => getModel(roles.generator) || C.CATALOG.find(m => m.runtime === 'sd');
  const famOf = () => C.FAMILIES[(genModel() || {}).family] || C.FAMILIES.turbo;
  function field(label, el) { const w = h('div'); w.append(h('label', null, label), el); return w; }
  function numIn(get, set, step, min) {
    const i = h('input', 'in'); i.type = 'number'; i.step = String(step || 1); if (min != null) i.min = String(min); i.value = get();
    i.onchange = () => { const v = parseFloat(i.value); if (isFinite(v)) { set(v); saveCfg(); render(); } }; return i;
  }
  function controlsBox() {
    const d = document.createElement('details'); d.open = true;
    d.append(h('summary', null, '🎛 کنترل‌های ساخت تصویر'));
    const fam = famOf(), e = C.genParams(genModel() || {}, cfg);
    d.append(note('مدل: ' + (genModel() ? genModel().name : '—') + ' · ' + fam.title), chip('مؤثر: ' + ptxt(e)));
    const pr = h('div');
    [['fast', '⚡ سریع'], ['balanced', '⚖️ متوازن'], ['quality', '✨ کیفیت']].forEach(([k, t]) => {
      const b = h('button', 'sbtn', t); b.onclick = () => { cfg.gen.size = fam.presets[k][0]; cfg.gen.steps = fam.presets[k][1]; saveCfg(); render(); }; pr.append(b);
    });
    const rs = h('button', 'sbtn', '↺ پیش‌فرض مدل'); rs.onclick = () => { cfg.gen = Object.assign({}, C.DEFAULTS.gen, { negative: cfg.gen.negative || '' }); saveCfg(); render(); };
    pr.append(rs); d.append(pr);
    const g = h('div', 'grid2');
    const sz = h('select', 'in'); [256, 384, 512, 640, 768, 1024].filter(x => x <= fam.maxSize).forEach(x => sz.append(new Option(x + '×' + x, x))); sz.value = e.size;
    sz.onchange = () => { cfg.gen.size = Number(sz.value); saveCfg(); render(); };
    const sm = h('select', 'in'); C.SAMPLERS.forEach(x => sm.append(new Option(x, x))); sm.value = e.sampler; sm.onchange = () => { cfg.gen.sampler = sm.value; saveCfg(); render(); };
    const sd = h('select', 'in'); [['inc', 'ثابت+شماره'], ['fixed', 'ثابت'], ['random', 'تصادفی']].forEach(([k, t]) => sd.append(new Option(t, k))); sd.value = cfg.seedMode;
    sd.onchange = () => { cfg.seedMode = sd.value; saveCfg(); render(); };
    g.append(field('اندازه', sz), field('Steps', numIn(() => e.steps, v => { cfg.gen.steps = v; }, 1, 1)), field('CFG', numIn(() => e.cfg, v => { cfg.gen.cfg = v; }, 0.1, 0)),
      field('Sampler', sm), field('Seed', sd), field('مقدار Seed', numIn(() => cfg.seed, v => { cfg.seed = v; }, 1, 0)));
    if (mode === 'direct') g.append(field('تعداد تصویر (۱ تا ۶)', numIn(() => cfg.count, v => { cfg.count = Math.max(1, Math.min(6, Math.round(v))); }, 1, 1)));
    else g.append(field('حداکثر دور', numIn(() => cfg.maxRounds, v => { cfg.maxRounds = Math.max(1, Math.round(v)); }, 1, 1)));
    if (mode === 'loop') g.append(field('امتیاز قبولی (۰ تا ۱۰)', numIn(() => cfg.acceptScore, v => { cfg.acceptScore = v; }, 0.5, 0)));
    if (mode !== 'direct') g.append(field('قدرت ویرایش', numIn(() => cfg.strength, v => { cfg.strength = Math.max(0.1, Math.min(1, v)); }, 0.05, 0.1)));
    d.append(g);
    const neg = h('textarea', 'in'); neg.rows = 2; neg.placeholder = 'پرامپت منفی (انگلیسی)'; neg.value = cfg.gen.negative || ''; neg.style.direction = 'ltr'; neg.disabled = !fam.negative;
    neg.onchange = () => { cfg.gen.negative = neg.value; saveCfg(); };
    d.append(field('پرامپت منفی', neg));
    if (!fam.negative) d.append(note('این خانواده با cfg=1 کار می‌کند و پرامپت منفی اثر ندارد (غیرفعال شد).'));
    return d;
  }
  const phIcon = s => s === 'run' ? '⏳' : s === 'done' ? '✅' : '❌';
  const STATUS = { accepted: '✅ تصویر پذیرفته شد', max_rounds: '⚠️ به سقف دورها رسید؛ بهترین تصویر نمایش داده می‌شود', stopped: '⏹ متوقف شد', done: '✅ ساخته شد' };
  function itemOf(run, round) {
    const o = (run.outputs || []).find(x => x.round === round) || {}, im = view && view.images[round];
    return { path: o.path, prompt: o.prompt, seed: o.seed, params: o.params, model: o.model, dataUrl: im && im.dataUrl, ts: run.ts, request: run.request, mode: run.mode };
  }
  function reviewPanel() {
    const inf = pendingReview.info, c = h('div', 'card2');
    c.append(h('div', 'mt', '⏸ نوبت تصمیم تو (دور ' + inf.round + ')'));
    c.append(note('امتیاز نقدکننده: ' + (inf.score == null ? '؟' : inf.score) + ' · پیشنهاد مدل: ' + inf.suggested + (inf.problems && inf.problems.length ? '\n' + inf.problems.join(' | ') : '')));
    const ta = h('textarea', 'in'); ta.rows = 3; ta.value = inf.prompt; ta.style.direction = 'ltr';
    c.append(h('div', 'note', 'پرامپت دور بعد (قابل ویرایش):'), ta);
    const row = h('div'); row.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin-top:8px';
    const pick = (label, action, off) => { const b = h('button', action === 'accept' ? 'btn' : 'btn ghost', label); b.disabled = !!off; b.onclick = () => { const rv = pendingReview; pendingReview = null; rv.resolve({ action, prompt: ta.value }); paintRun(); }; row.append(b); };
    pick('قبول', 'accept'); pick('ساخت دوباره', 'regenerate', inf.isLast); pick('ویرایش', 'edit', inf.isLast || !inf.canEdit); pick('توقف', 'stop');
    c.append(row);
    if (!inf.canEdit) c.append(note('ویرایشگر انتخاب نشده؛ «ویرایش» غیرفعال است.'));
    return c;
  }
  function paintRun() {
    if (!runArea || !runArea.isConnected) return;
    runArea.textContent = '';
    if (!view) return;
    if (view.error) { runArea.append(h('div', 'note fail', view.error)); return; }
    const run = view.run; if (!run) return;
    const tl = h('div', 'card2 tl'); tl.append(h('div', 'mt', 'خط زمانی (هر مدل یک پردازش جدا؛ پایان پردازش = خاموش شدن مدل)'));
    run.phases.forEach(p => tl.append(h('div', 'ph ' + p.status, phIcon(p.status) + ' ' + (p.round ? 'R' + p.round : 'R0') + ' · ' + C.ROLES[p.role].title + ' · ' + p.model + ' · ' + p.action +
      (p.ms ? ' · ' + fmt(p.ms / 1000) + 's' : '') + (p.ramFreeMb != null ? ' · free ' + fmt(p.ramFreeMb / 1024) + 'GB' : '') + (p.note ? ' · ' + p.note : ''))));
    runArea.append(tl);
    if (view.plan) {
      const c = h('div', 'card2'); c.append(h('div', 'mt', view.plan.user ? 'پرامپت (از خودت)' : 'پرامپت سرپرست'), h('div', 'pre', view.plan.prompt));
      if (!view.plan.parsed) c.append(note('JSON معتبر نبود؛ درخواست خودت به‌عنوان پرامپت استفاده شد.', 'warn'));
      if (view.plan.think) { const d = document.createElement('details'); d.append(h('summary', null, '💭 تفکر سرپرست'), h('div', 'pre', view.plan.think)); c.append(d); }
      runArea.append(c);
    }
    run.rounds.forEach(r => {
      const c = h('div', 'card2'), im = view.images[r.n], cr = view.critics[r.n], dc = view.decisions[r.n];
      c.append(h('div', 'mt', (run.mode === 'direct' ? 'تصویر ' : 'دور ') + r.n + ' — ' + (r.kind === 'edit' ? 'ویرایش' : 'ساخت')));
      if (im) {
        const img = document.createElement('img'); img.className = 'rimg'; img.src = im.dataUrl; img.onclick = () => openViewer(itemOf(run, r.n)); c.append(img);
        c.append(chip('🎲 seed ' + im.seed), chip(ptxt(im.params)));
        const row = h('div');
        const sb = h('button', 'sbtn', 'ذخیره PNG'); sb.onclick = () => msg(saveResult(itemOf(run, r.n)));
        const cp = h('button', 'sbtn', 'کپی پرامپت'); cp.onclick = () => { try { navigator.clipboard.writeText(r.prompt); } catch (e) {} msg('پرامپت:\n' + r.prompt); };
        row.append(sb, cp); c.append(row);
      }
      c.append(h('div', 'pre', r.prompt));
      if (cr) {
        const line = h('div'); line.append(chip('امتیاز: ' + (cr.score == null ? '؟' : cr.score), cr.score == null ? 'warn' : ''));
        if (dc) line.append(chip('تصمیم: ' + dc.decision + (dc.by ? ' (' + dc.by + ')' : ''), dc.decision === 'accept' ? '' : 'warn'));
        c.append(line);
        const d = document.createElement('details'); d.open = true;
        d.append(h('summary', null, '🔍 تفکر و تحلیل نقدکننده'));
        if (cr.think) d.append(h('div', 'note', 'تفکر خام مدل:'), h('div', 'pre', cr.think));
        d.append(h('div', 'pre', cr.analysis || '—'));
        if (cr.problems && cr.problems.length) d.append(h('div', 'pre', 'Problems: ' + cr.problems.join(' | ')));
        if (dc && dc.reason) d.append(h('div', 'pre', 'Reason: ' + dc.reason));
        if (dc && dc.note) d.append(note(dc.note, 'warn'));
        const raw = document.createElement('details'); raw.append(h('summary', null, 'خروجی خام'), h('div', 'pre', cr.raw || '')); d.append(raw);
        c.append(d);
      }
      runArea.append(c);
    });
    if (pendingReview) runArea.append(reviewPanel());
    if (view.final) {
      const f = view.final, c = h('div', 'card2');
      c.append(h('div', 'mt', f.status === 'error' ? '❌ خطا: ' + (f.error || '') : (STATUS[f.status] || f.status)));
      c.append(note('زمان کل: ' + fmt((f.ms || 0) / 1000) + ' ثانیه · جابه‌جایی مدل: ' + f.swaps + ' · تصویر ساخته‌شده: ' + (f.outputs ? f.outputs.length : 0)));
      if (f.final && view.images[f.final.round]) {
        const img = document.createElement('img'); img.className = 'rimg'; img.src = view.images[f.final.round].dataUrl; img.onclick = () => openViewer(itemOf(f, f.final.round)); c.append(img);
        const sb = h('button', 'btn', 'ذخیره‌ی نتیجه در Downloads'); sb.onclick = () => msg(saveResult(itemOf(f, f.final.round)));
        const si = h('button', 'btn ghost', 'ذخیره با اطلاعات (JSON)'); si.onclick = () => msg(saveInfo(itemOf(f, f.final.round)));
        const row = h('div'); row.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap'; row.append(sb, si); c.append(row);
      }
      runArea.append(c);
    }
  }
  function onEv(ev) {
    if (ev.type === 'start') view.run = ev.run;
    else if (ev.type === 'plan') view.plan = ev;
    else if (ev.type === 'image') view.images[ev.round] = ev;
    else if (ev.type === 'critic') view.critics[ev.round] = ev;
    else if (ev.type === 'decision') view.decisions[ev.round] = ev;
    else if (ev.type === 'final') view.final = ev.run;
    if (ev.type === 'phase') UI.studio.seatState(ev.ph.role, ev.ph.status);
    if (ev.type === 'final') ['supervisor', 'generator', 'critic', 'editor'].forEach(r => UI.studio.seatState(r, 'idle'));
    paintRun();
  }
  async function startRun() {
    if (running) return;
    const text = reqText.trim();
    if (!text) { msg(mode === 'direct' ? 'پرامپت (انگلیسی) را بنویس.' : 'اول بنویس چه تصویری می‌خواهی.'); return; }
    refresh();
    const v = C.validateRoles(roles, models(), lib, mode);
    if (!v.ok) { view = { error: v.errors.join('\n') }; paintRun(); return; }
    const used = C.MODES[mode].roles.concat(mode !== 'direct' && roles.editor ? ['editor'] : []);
    const info = AIChat.info();
    const need = Math.max(...used.map(r => C.estimateRamMb(getModel(roles[r]), lib[roles[r]])));
    const go = async () => {
      running = true; stopFlag = false; pendingReview = null;
      view = { run: null, plan: null, images: {}, critics: {}, decisions: {}, final: null }; render();
      const run = await C.runStudio({ request: text, mode, promptOverride: mode === 'direct' ? text : promptText, roles, models: models(), lib, libRoot: rt.libRoot, settings: cfg, tools, onEvent: onEv,
        shouldStop: () => stopFlag, review: info2 => new Promise(resolve => { pendingReview = { info: info2, resolve }; paintRun(); }),
        ram: async () => { const i = AIChat.info(); return i ? i.ramAvailMb : null; } })
        .catch(e => ({ status: 'error', error: String(e.message || e), phases: [], rounds: [], outputs: [], swaps: 0, ms: 0, ts: Date.now(), roles: {}, mode }));
      running = false; pendingReview = null;
      if (!view.final) view.final = run;
      runs.unshift({ ts: run.ts, mode: run.mode, request: text, status: run.status, ms: run.ms, swaps: run.swaps, error: run.error || null, roles: run.roles,
        rounds: run.rounds.map(r => ({ n: r.n, kind: r.kind, score: r.score, decision: r.decision, seed: r.seed })),
        phases: run.phases.map(p => ({ round: p.round, role: p.role, action: p.action, model: p.model, ms: p.ms, ramFreeMb: p.ramFreeMb, status: p.status })) });
      runs = runs.slice(0, 20); sv('studio_runs', runs);
      await addToGallery(run); render();
    };
    if (info && info.ramAvailMb < need) ask('رم آزاد (' + info.ramAvailMb + ' MB) کمتر از برآورد این ترکیب (' + need + ' MB) است. ممکن است اندروید برنامه را ببندد. ادامه؟', 'ادامه', go); else go();
  }
  function stopRun() { stopFlag = true; tools.cancelAll(); if (pendingReview) { const rv = pendingReview; pendingReview = null; rv.resolve({ action: 'stop' }); } }
  R.run = b => {
    const seg = h('div', 'seg2');
    Object.entries(C.MODES).forEach(([k, m]) => { const x = h('button', mode === k ? 'on' : '', m.title); x.disabled = running; x.onclick = () => { mode = k; sv('studio_mode', mode); render(); }; seg.append(x); });
    b.append(seg, note(C.MODES[mode].desc));
    const v = C.validateRoles(roles, models(), lib, mode);
    if (!v.ok) { v.errors.forEach(e => b.append(h('div', 'note fail', '⛔ ' + e))); const g = h('button', 'sbtn', 'رفتن به تب نقش‌ها'); g.onclick = () => { tab = 'roles'; render(); }; b.append(g); }
    const ta = h('textarea', 'in'); ta.rows = 3; ta.value = reqText; if (mode === 'direct') ta.style.direction = 'ltr';
    ta.placeholder = mode === 'direct' ? 'English prompt, e.g. a cozy wooden cabin in a snowy forest, warm light' : 'چه تصویری می‌خواهی؟ (فارسی یا انگلیسی)';
    ta.oninput = () => { reqText = ta.value; sv('studio_req', reqText); };
    b.append(ta);
    if (mode !== 'direct') {
      const d = document.createElement('details'); d.append(h('summary', null, 'پرامپت دقیق خودم (اختیاری، انگلیسی)'));
      const pt = h('textarea', 'in'); pt.rows = 2; pt.style.direction = 'ltr'; pt.value = promptText; pt.placeholder = 'اگر پر شود، سرپرست پرامپت اول را نمی‌نویسد و همین استفاده می‌شود';
      pt.oninput = () => { promptText = pt.value; sv('studio_prompt', promptText); }; d.append(pt); b.append(d);
    }
    b.append(controlsBox());
    const row = h('div'); row.style.cssText = 'display:flex;gap:8px;margin:10px 0';
    const go = h('button', 'btn', running ? 'در حال اجرا…' : 'شروع'); go.disabled = running; go.onclick = startRun;
    const stop = h('button', 'btn ghost', 'توقف'); stop.disabled = !running; stop.onclick = stopRun;
    row.append(go, stop); b.append(row);
    runArea = h('div'); b.append(runArea); paintRun();
    const d = document.createElement('details'); d.append(h('summary', null, '⚙️ تنظیمات فنی'));
    const g = h('div', 'grid2');
    [['thread', 'threads', 1, 1], ['کانتکست', 'ctx', 512, 512], ['دمای متن', 'temp', 0.1, 0]].forEach(([label, key, step, min]) => g.append(field(label, numIn(() => cfg[key], v2 => { cfg[key] = v2; }, step, min))));
    const ex = (label, key) => { const i = h('input', 'in'); i.value = cfg.extra[key]; i.style.direction = 'ltr'; i.onchange = () => { cfg.extra[key] = i.value; saveCfg(); }; return field(label, i); };
    d.append(g, ex('فلگ‌های اضافه llama-cli', 'llama'), ex('فلگ‌های اضافه llama-mtmd-cli', 'mtmd'), ex('فلگ‌های اضافه sd-cli', 'sd'),
      note('اگر ابزار با خطای «unknown argument» بسته شد، این فلگ‌ها را اصلاح کن (نسخه‌ی ابزار ممکن است فلگ‌ها را عوض کرده باشد).'));
    b.append(d);
  };

  // ---------- Gallery tab ----------
  R.gal = b => {
    if (!gallery.length) { b.append(note('هنوز تصویری در گالری نیست. بعد از اولین ساخت، نتیجه‌ها اینجا می‌مانند (فقط نسخه‌ی کوچک؛ فایل کامل در حافظه‌ی موقت است و با «ذخیره» باید به Downloads برود).')); return; }
    b.append(note(gallery.length + ' تصویر. روی تصویر بزن تا بزرگ شود.'));
    const grid = h('div', 'gal');
    gallery.forEach(it => {
      const c = h('div', 'gcard');
      if (it.thumb) { const im = document.createElement('img'); im.src = it.thumb; im.onclick = () => openViewer(it); c.append(im); } else { const p = h('div', 'gph', 'بدون پیش‌نمایش'); p.onclick = () => openViewer(it); c.append(p); }
      c.append(h('div', 't', (it.prompt || '').slice(0, 90)), chip('seed ' + it.seed), it.score != null ? chip('★ ' + it.score) : h('span'));
      const row = h('div');
      const re = h('button', 'sbtn', 'استفاده دوباره'); re.onclick = () => { reqText = it.mode === 'direct' ? it.prompt : it.request; promptText = it.mode === 'direct' ? '' : it.prompt; mode = it.mode || 'loop'; cfg.seedMode = 'fixed'; cfg.seed = it.seed || 0; if (it.params) { cfg.gen.size = it.params.size; cfg.gen.steps = it.params.steps; cfg.gen.cfg = it.params.cfg; cfg.gen.sampler = it.params.sampler; } sv('studio_req', reqText); sv('studio_prompt', promptText); sv('studio_mode', mode); saveCfg(); tab = 'run'; render(); };
      const sv2 = h('button', 'sbtn', 'ذخیره'); sv2.onclick = () => msg(saveResult(it));
      const dl = h('button', 'sbtn', 'حذف'); dl.onclick = () => { gallery = gallery.filter(x => x.id !== it.id); sv('studio_gallery', gallery); render(); };
      row.append(re, sv2, dl); c.append(row); grid.append(c);
    });
    b.append(grid);
  };

  // ---------- Experiments tab ----------
  async function toolCheck() {
    if (testBusy) return; testBusy = true; tests = tests.filter(t => !/^--help/.test(t.name)); render();
    for (const [name, t] of Object.entries(rt.tools)) {
      if (!t.exists) { tests.push({ name: '--help ' + name, status: 'FAIL', ms: 0, out: 'binary missing' }); continue; }
      const r = await tools.run(name, ['--help'], { timeoutSec: 60 });
      const text = (r.out + '\n' + r.err).trim();
      tests.push({ name: '--help ' + name, status: text.length > 50 ? 'PASS' : 'FAIL', ms: r.ms, out: text.split('\n').slice(0, 14).join('\n') + '\n(exit ' + r.code + ')' });
    }
    testBusy = false; sv('studio_tests', tests); render();
  }
  async function quickTests() {
    if (testBusy) return; refresh();
    const v = C.validateRoles(roles, models(), lib, 'loop'); if (!v.ok) { msg('اول نقش‌ها را درست انتخاب کن:\n' + v.errors.join('\n')); return; }
    testBusy = true; tests = tests.filter(t => !/^quick/.test(t.name)); render();
    const ctx = { settings: Object.assign({}, cfg, { gen: Object.assign({}, cfg.gen, { size: 256, steps: 1 }) }), tools, lib, libRoot: rt.libRoot };
    const dir = await tools.newRunDir('quick' + Date.now());
    const rec = async (name, fn) => { const t0 = Date.now(); try { const r = await fn(); tests.push({ name: 'quick ' + name, status: r.pass ? 'PASS' : 'WARN', ms: Date.now() - t0, out: r.out }); } catch (e) { tests.push({ name: 'quick ' + name, status: 'FAIL', ms: Date.now() - t0, out: String(e.message || e) }); } render(); };
    const sup = getModel(roles.supervisor), gen = getModel(roles.generator), cri = getModel(roles.critic), edi = roles.editor ? getModel(roles.editor) : null;
    await rec('supervisor: reply OK', async () => { const r = await C.runLlm(ctx, sup, 'You are concise.', 'Reply with the single word OK.', { n: 8 }); return { pass: /ok/i.test(r.text), out: r.text }; });
    const img = dir + '/q_gen.png';
    await rec('generator: tiny image', async () => { await C.runSd(ctx, gen, { prompt: 'a red apple on a wooden table, photo', out: img, seed: 1 }); return { pass: true, out: 'ساخته شد' }; });
    await rec('critic: describe image', async () => { const r = await C.runLlm(ctx, cri, 'You are a visual critic.', 'Describe this image in one sentence.', { n: 60, image: img }); return { pass: r.text.length > 5, out: r.text }; });
    if (edi) await rec('editor: img2img', async () => { await C.runSd(ctx, edi, { prompt: 'a green apple on a wooden table, photo', out: dir + '/q_edit.png', seed: 2, image: img }); return { pass: true, out: 'ساخته شد' }; });
    testBusy = false; sv('studio_tests', tests); render();
  }
  R.exp = b => {
    b.append(h('h4', null, 'آزمایش ابزارها'));
    b.append(note('اول «بررسی ابزارها» را بزن تا مطمئن شویم باینری‌ها روی گوشی اجرا می‌شوند. بعد «تست سریع» هر نقش انتخاب‌شده را با یک کار کوچک امتحان می‌کند.'));
    const b1 = h('button', 'btn lbtn', 'بررسی ابزارها (--help)'); b1.disabled = testBusy || running || !rt; b1.onclick = toolCheck;
    const b2 = h('button', 'btn lbtn', testBusy ? 'در حال اجرا…' : 'تست سریع نقش‌ها'); b2.disabled = testBusy || running || !rt; b2.onclick = quickTests;
    b.append(b1, b2);
    tests.forEach(t => {
      const d = document.createElement('details'); d.className = 'card2';
      d.append(h('summary', null, (t.status === 'PASS' ? '✅ ' : t.status === 'WARN' ? '⚠️ ' : '❌ ') + t.name + ' · ' + fmt((t.ms || 0) / 1000) + 's'), h('div', 'pre', t.out || ''));
      b.append(d);
    });
    b.append(h('h4', null, 'حافظه‌ی موقت استودیو'));
    let si = { bytes: 0, files: 0 }; try { si = tools.studioInfo(); } catch (e) {}
    const cc = h('div', 'card2'); cc.append(note('تصویرهای کامل در حافظه‌ی موقت‌اند (' + si.files + ' فایل، ' + mb(si.bytes) + '). گالری فقط نسخه‌ی کوچک را نگه می‌دارد.'));
    const clr = h('button', 'btn ghost', 'پاک کردن حافظه‌ی موقت'); clr.onclick = () => ask('تصویرهای کامل پاک شوند؟ (نسخه‌های کوچک گالری می‌مانند؛ ذخیره‌شده‌های Downloads دست‌نخورده‌اند.)', 'پاک کن', () => { tools.clearStudio(); render(); });
    cc.append(clr); b.append(cc);
    b.append(h('h4', null, 'اجراهای قبلی'));
    if (!runs.length) b.append(note('هنوز اجرایی ثبت نشده.'));
    runs.forEach(r => {
      const d = document.createElement('details'); d.className = 'card2';
      d.append(h('summary', null, new Date(r.ts).toLocaleString('fa-IR') + ' · ' + (C.MODES[r.mode] ? C.MODES[r.mode].title : '') + ' · ' + r.status + ' · ' + fmt((r.ms || 0) / 1000) + 's · swaps ' + r.swaps));
      d.append(h('div', 'pre', 'Request: ' + r.request + '\nRoles: ' + JSON.stringify(r.roles) + '\nRounds: ' + r.rounds.map(x => '#' + x.n + ' ' + x.kind + ' seed=' + x.seed + ' score=' + x.score + ' ' + x.decision).join(' | ') + (r.error ? '\nError: ' + r.error : '')));
      d.append(h('div', 'pre', r.phases.map(p => p.round + ' ' + p.role + '/' + p.action + ' ' + p.model + ' ' + fmt(p.ms / 1000) + 's ' + p.status).join('\n')));
      b.append(d);
    });
    const ex = h('button', 'btn ghost lbtn', 'خروجی آزمایش‌ها (بدون متن درخواست‌ها) در Downloads');
    ex.onclick = () => { const data = { settings: cfg, tests: tests.map(t => ({ name: t.name, status: t.status, ms: t.ms })),
      runs: runs.map(r => ({ ts: r.ts, mode: r.mode, status: r.status, ms: r.ms, swaps: r.swaps, rounds: r.rounds, phases: r.phases, error: r.error })) };
      msg('نتیجه: ' + AIChat.save('studio_experiments.json', JSON.stringify(data, null, 2))); };
    b.append(ex);
  };

  // ---------- Web room: the search tool lives in the persistent iframe #web-frame (owned by the UI) ----------
  const hasNet = typeof window.SearchBridge !== 'undefined';
  const webFrame = $('#web-frame');
  // The native bridge answers in the main frame; forward it to the search page.
  window.onHttpResult = (id, status, text, err) => {
    const w = webFrame && webFrame.contentWindow;
    if (w && typeof w.onHttpResult === 'function') w.onHttpResult(id, status, text, err);
  };
  UI.web.init({ available: hasNet, enabled: hasNet && window.SearchBridge.enabled(), hosts: hasNet ? window.SearchBridge.hosts() : '', src: 'search-tool.html',
    onToggle: on => window.SearchBridge.setEnabled(on) });
  // For later tool-calling: window.WebSearch.call('query') -> text for the model
  window.WebSearch = {
    available: () => hasNet && !!webFrame && !!webFrame.contentWindow && !!webFrame.contentWindow.SearchTool,
    call: (query, args) => {
      const w = webFrame && webFrame.contentWindow;
      if (!w || !w.SearchTool) return Promise.resolve('search_error: open the web room once first');
      return w.SearchTool.call('web_search', Object.assign({ query }, args || {}));
    }
  };

  // ---------- shell ----------
  const TABS = [['models', 'مدل‌ها'], ['roles', 'نقش‌ها'], ['run', 'ساخت'], ['gal', 'گالری'], ['exp', 'آزمایش‌ها']];
  function render() {
    const body = $('#st-body'); if (!body) return;
    const tb = $('#st-tabs'); tb.textContent = '';
    TABS.forEach(([k, t]) => { const x = h('button', k === tab ? 'on' : '', t); x.onclick = () => { tab = k; render(); }; tb.append(x); });
    const y = body.parentElement.scrollTop; body.textContent = ''; runArea = null; R[tab](body); body.parentElement.scrollTop = y;
  }
  $('#bstudio').onclick = () => { refresh(); render(); openPanel('#sheet-studio'); };
  refresh();
  UI.studio.setSeats(seatsOf());
})();
