# رابط «کانون» برای Offline AI

این بسته **فقط ظاهر (UI)** است. هیچ منطق مدل، دانلود، جستجو یا ذخیره‌سازی گفتگو در آن نیست؛ هر بخش یک «نقطهٔ اتصال» دارد (با `data-hook` و `id` مشخص) و این README می‌گوید کدام کد اجرایی به کدام نقطه وصل می‌شود.

## ۱. فایل‌ها و نصب سریع

| فایل | کار |
|---|---|
| `index.html` | جایگزین `app/src/main/assets/index.html` (فقط UI، با یک لایهٔ دمو که قابل حذف است) |
| `README.md` | همین راهنما |

بقیهٔ فایل‌های `assets` (`ai-chat.js`، `lab.js`، `studio-core.js`، `studio.js`، `search-tool.html`) و همهٔ کدهای Kotlin **بدون تغییر** می‌مانند، به‌جز دو ویرایش کوچک در بخش ۶.

سه مرحله:

1. `index.html` جدید را جایگزین قبلی کن.
2. منطق چت قدیمی (اسکریپت داخل `index.html` قدیمی) را در فایل جدید `chat-controller.js` بگذار و طبق بخش ۴ و ۵ سبک کن.
3. در انتهای `index.html` (جایی که کامنت `SCRIPT 2` هست) این ترتیب را بنویس:

```html
<script src="ai-chat.js"></script>
<script src="chat-controller.js"></script>
<script src="lab.js"></script>
<script src="studio-core.js"></script>
<script src="studio.js"></script>
```

بلوک `<script id="demo-layer">` وقتی `AIChat` تعریف باشد خودش کاری نمی‌کند؛ برای کم‌کردن حجم می‌توانی حذفش کنی.

## ۲. ایدهٔ طراحی (کوتاه)

**استعاره: کانون (آتشدان).** مدل مهمانی است که شبانه کنار آتشِ گوشی‌ات می‌نشیند. رنگ‌ها از فرهنگ دیداری ایرانی می‌آیند: لاجورد (پس‌زمینه)، زعفرانیِ اخگر (مدل و اقدام اصلی)، فیروزه‌ای (ترجمه، «آفلاین/آماده»)، و انار (گرما و خطا). تم روشن «سپیده» کاغذی گرم است: پس‌زمینه `#F4EBE2`، سطح‌ها `#FDF6EE` و `#F8EAE3` و `#F7E9E1`، حاشیه `#b78050`، رنگ اصلی `#7A4614` و درخشش `#F5B98B` (متغیرها در بالای `<style>`).

| تصمیم در UI | الهام |
|---|---|
| گفتگو شبانه و کم‌شلوغ است؛ اخگر نشانهٔ زنده بودن مدل است | Wiessner (2014): در ثبت‌های ۱۹۷۴ مردم Ju/’hoansi، حدود ۸۱٪ گفتگوهای کنار آتشِ شب قصه بود و فقط ۶٪ گفتگوی روز؛ روز دربارهٔ کار و نظم اجتماعی بود. |
| انتخاب مدل = سه ایستگاه: «انتخاب ← گذر ← ورود» | مناسک گذار (van Gennep، Turner): جدایی، حالت میانی، پیوستن. به‌جای چرخندهٔ بی‌معنی، کاربر می‌بیند در کدام مرحله است. |
| اخگر با سرعت تولید (tok/s) سوسو می‌زند | شفاهیت (Ong): پاسخ مثل گفتار «گفته می‌شود»، نه مثل صفحهٔ چاپی ظاهر می‌شود. |
| ترجمهٔ فارسی زیر پاسخ، با جداکنندهٔ ستارهٔ هشت‌پر (خاتم) و رنگ فیروزه‌ای | حاشیه‌نویسی/مترجمِ کنار گوینده. دو صدا با دو رنگ و دو خط جدا می‌مانند. |
| استودیو: چهار نقش دور یک میز | کارگاه و شاگرد/استاد (Lave & Wenger) و شناخت توزیع‌شده (Hutchins): هر مدل یک «صندلی» دارد. |
| وب: «دروازه» که پیش‌فرض بسته است | مهمان‌داری و مرز: آفلاین بودن یک وضعیت قابل‌دیدن است، نه یک جملهٔ پنهان. مهر بالای صفحه همیشه می‌گوید «آفلاین» یا «وب روشن». |
| فقط اعداد اندازه‌گیری‌شده | همان قانون `lab.js`: رابط ادعا نمی‌کند، اندازه می‌گیرد. |

از مرور رابط ChatGPT، Claude، Gemini، Perplexity و DeepSeek این الگوهای آشنا نگه داشته شد تا یادگیری لازم نباشد: فهرست گفتگوها در کشو، نوار نوشتن پایین صفحه، انتخابگر حالت پاسخ که همیشه دیده می‌شود، و «فکر مدل» که جمع‌شونده است. چیزی که عوض شد هویت است، نه جای دکمه‌ها.

منابع: Wiessner, P. W. (2014), *Embers of society: Firelight talk among the Ju/’hoansi Bushmen*, PNAS 111(39):14027–14035, doi:10.1073/pnas.1404212111. مقایسه‌های رابط‌ها: uxdesign.cc («Thinking past the cliché of LLMs»)، builtin.com («The Design Pattern That’s Taken Over AI»)، و teardown‌های aiuxplayground.com.

## ۳. قرارداد بین UI و کد

### UI این‌ها را تعریف می‌کند (کنترلر **نباید** دوباره تعریفشان کند)

`$`، `$$`، `h`، `fmt`، `ask(msg, okText, cb)`، `closeAll()`، `openPanel(sel)` و شیء `window.UI`.

اگر کنترلر یکی از این‌ها را دوباره با `const` یا `function` تعریف کند، خطای «already declared» می‌دهد و کل اسکریپت از کار می‌افتد.

`openPanel` نگاشتِ شیت‌های قدیمی را هم انجام می‌دهد، پس `lab.js` و `studio.js` بدون تغییر کار می‌کنند:

| فراخوانی قدیمی | در UI جدید |
|---|---|
| `openPanel('#sheet-studio')` | رفتن به اتاق «استودیو» |
| `openPanel('#sheet-lab')` | اتاق «آزمایشگاه»، تب «ابزارها» |
| `openPanel('#sheet-rep')` | اتاق «آزمایشگاه»، تب «گزارش» |
| `openPanel('#drawer')` و `openPanel('#sheet-set')` | همان کشو و شیت تنظیمات |

### کنترلر این‌ها را نگه می‌دارد (`lab.js` و `studio.js` به آن‌ها نیاز دارند)

`chats`، `cur()`، `curId`، `save()`، `mode`، `SID`، `status`، `busy`، `lastInfo`، `pollInfo()`.

## ۴. نقشهٔ اتصال: بخش UI ← کد اجرایی

| بخش UI | نقطهٔ اتصال | کد اجرایی | چگونه وصل شود |
|---|---|---|---|
| **اخگر** (بالا، صفحهٔ ورود، صفحهٔ خالی) | `data-ember` | `AIChat.onStatus` و `AIChat.status()` (ریشه: `AI.status()` و رویداد `window.onAiStatus`) | `AIChat.onStatus = (s, d) => { status = s; UI.setStatus(s, d); }` و یک‌بار `UI.setStatus(AIChat.status(), '')`. مقدارها: `need_model` / `loading` / `ready` / `error`. اخگر خودکار می‌شود: خاکستر، افروختن، آرام، فکر، سخن‌گفتن، خطا. |
| **اخگر هنگام تولید** | `UI.setBusy`، `UI.setLive` | callback توکن در `AIChat.send` | `UI.setBusy(true)` در شروع و `UI.setBusy(false)` در پایان. هر ~۳۰۰ms `UI.setLive(tokPerSec)` را صدا بزن؛ سرعت سوسو از همین می‌آید. |
| **صفحهٔ ورود (سه ایستگاه)** | `#threshold`، دکمه `#pick` | `AIChat.pickModel()` (ریشه: `AI.pickModel()` ← انتخابگر فایل ← `importModel`) | `$('#pick').onclick = () => AIChat.pickModel();`. متن خطای بارگذاری از `d` در `UI.setStatus` می‌آید و زیر دکمه نمایش داده می‌شود. |
| **نوار رم** (زیر هدر) | `#mtxt`، `#membar`، `#live` | `AIChat.info()` (ریشه: `AI.info()`) | هر ۲٫۵ ثانیه: `lastInfo = AIChat.info(); UI.setInfo(lastInfo);` (فیلدها: `ramTotalMb`، `ramAvailMb`، `appPssMb`، `modelName`). |
| **مهر آفلاین/وب روشن** | `#seal` | `SearchBridge.enabled()` | با `UI.web.setNet(bool)` خودکار عوض می‌شود (بخش وب پایین). |
| **لیست پیام‌ها** | `#log` | داده‌های `chats` (همان شکل قبلی: `role`، `text`، `raw`، `fa`، `st`، `err`، `sess`) | `UI.chat.render(cur(), SID)`. اگر گفتگو خالی باشد صفحهٔ خوش‌آمد و «سنگ‌ریزه»ها دیده می‌شود. اگر آخرین پیام از نشست قبلی باشد، هشدار نمایش داده می‌شود. |
| **حباب‌های جدید و استریم** | `UI.chat.makeUser/makeAi/paintAi/append` | `AIChat.send(prompt, onEnglish, onPersian, onToken, onError, opts)` | هر توکن: `m.raw += tok` سپس `UI.chat.paintAi(el, m, true)`؛ پایان: `UI.chat.paintAi(el, m, false)`. بلوک `<think>` و خط ترجمه و آمار را خود `paintAi` می‌کشد. متن «در انتظار» را با `el._r.wait.textContent = '...'` بنویس. |
| **ترجمهٔ فارسی زیر پاسخ** | `.gloss` | callback سوم `AIChat.send` (`onPersian`) | `m.fa = fa;` و دوباره `paintAi`. اگر `m.fa` خالی باشد جداکننده و خط فارسی نمایش داده نمی‌شود. |
| **نوار نوشتن** | `#inp`، `#go` | تابع `send()` کنترلر | `$('#go').onclick = send;` و Ctrl+Enter. متن را با `UI.composer.value()` بخوان و فقط **بعد از پذیرفتن** با `UI.composer.clear()` پاک کن (اگر `LAB.beforeSend()` متنی برگرداند پاک نکن). |
| **حالت پاسخ** (قرص‌های بالای نوار نوشتن + لیست تنظیمات) | `#modeChips`، `#modes` | متغیر `mode`، `buildPrompt()` | `UI.settings.renderModes(MODES, mode, k => { mode = k; save(); renderModes(); })`. هر دو جا با هم هماهنگ می‌شوند. |
| **کشوی گفتگوها** | `#clist`، `#bnew`، `#bmenu` | `chats` در `localStorage`، `makeChat()`، `AIChat.restart()` | `UI.drawer.render(chats, curId, onOpen, onDelete)`؛ `#bnew.onclick` همان منطق قبلی (از جمله پیام «حافظهٔ مدل پاک شود؟»). |
| **تنظیمات** | `#delall` | حذف همهٔ گفتگوها | `$('#delall').onclick` همان قبلی. «پوسته» و «اندازهٔ متن» فقط UI هستند و در `localStorage` (`ui_theme`، `ui_fs`) ذخیره می‌شوند. |
| **اتاق استودیو** | `#st-tabs`، `#st-body` | `studio.js` (`StudioCore` ← `window.Tools` ← `ToolBridge.kt`) | بدون تغییر: `studio.js` خودش داخل این دو می‌نویسد. دکمهٔ نوار پایین `#bstudio` همان دکمه‌ای است که `studio.js` به آن `onclick` می‌دهد. |
| **صندلی‌های استودیو** (اختیاری) | `#seats` | `roles` و رویداد `phase` در `studio.js` | بخش ۶-الف. |
| **اتاق آزمایشگاه ← تب ابزارها** | `#lab-tabs`، `#lab-body`، دکمهٔ نوار پایین `#blab` | `lab.js` (`window.LAB`) | بدون تغییر. `LAB.beforeSend()` و `LAB.maxOut()` همچنان در `send()` صدا زده می‌شوند. |
| **اتاق آزمایشگاه ← تب گزارش** | `#brep`، `#rep-body`، `#rep-tiles` | `openReport()` کنترلر | `$('#brep').onclick = openReport;`. تابع همچنان داخل `#rep-body` می‌نویسد (`kv`، `chart`، `textarea.rep`) و استایل جدید را می‌گیرد. برای چهار کاشی بالا: `UI.report.setSummary({ tps, ttft, n, ramFreeGb })`. |
| **ذخیرهٔ گزارش** | (در `lab.js`) | `AIChat.save(name, content)` ← `AI.saveReport` | بدون تغییر. |
| **اتاق وب (دروازه)** | `#net-toggle`، `#netHosts`، `#web-frame`، `#web-ph` | `SearchBridge.enabled()`، `setEnabled(bool)`، `hosts()`؛ `search-tool.html` | بخش ۶-ب. |
| **پنجرهٔ تأیید** | `ask()` | هر جا که تأیید لازم است | همان امضای قبلی: `ask(msg, okText, cb)`. اگر `cb` برابر `null` باشد فقط یک دکمه دیده می‌شود (پیام اطلاع‌رسانی). |
| **اعلان کوتاه** | `UI.toast(msg)` | هر جا لازم است | اختیاری. |

## ۵. چه چیزی از اسکریپت قدیمی `index.html` عوض شود

اسکریپت داخل `index.html` قدیمی را در `chat-controller.js` بگذار و این تغییرها را بده:

| در کد قدیمی | کار |
|---|---|
| تعریف `$`، `h`، `fmt`، `ask`، `closeAll`، `openPanel`، `dlgCb` و هندلرهای `#dno`/`#dyes`/`#bd` | **حذف** (UI دارد) |
| `updateComposer()` | **حذف** (`UI.setStatus`/`UI.setBusy` خودشان فعال/غیرفعال می‌کنند) |
| `setStatus(s, d)` | بدنه را به `{ status = s; UI.setStatus(s, d); }` تبدیل کن |
| `pollInfo()` | `lastInfo = i;` را نگه دار و رنگ‌آمیزی را با `UI.setInfo(i)` عوض کن |
| `makeUser`، `makeAi`، `paintAi`، `renderChat`، `updateBanner`، `nearBottom`، `toBottom`، `log` | **حذف**؛ معادل‌ها: `UI.chat.makeUser/makeAi/paintAi`، `UI.chat.render(cur(), SID)`، `UI.chat.nearBottom/toBottom` |
| `renderDrawer()` | بدنه: `UI.drawer.render(chats, curId, onOpen, onDelete)` |
| `renderModes()` | بدنه: `UI.settings.renderModes(MODES, mode, k => {...})` |
| در `send()`: `$('#inp').value = ''`، `log.appendChild`، `busy = true; updateComposer()`، `$('#live')...` | به ترتیب: `UI.composer.clear()`، `UI.chat.append(el)`، `UI.setBusy(true)`، `UI.setLive(tps)` |
| `openReport()` | همان بماند؛ فقط اگر دادهٔ میانگین دارد، یک خط `UI.report.setSummary(...)` اضافه کن |
| `makeChat()`، `save()`، `cur()`، `usedThisSession()`، `buildPrompt()`، `MODES`، `splitThink` (اگر جای دیگری لازم است) | **بدون تغییر** |

### اسکلت `chat-controller.js` (بخش‌های تغییرکرده)

```js
// chat-controller.js — loaded after ai-chat.js
const SID = AIChat.sessionId();
let chats = []; try { chats = JSON.parse(localStorage.getItem('chats_v2') || '[]'); } catch (e) {}
let curId = localStorage.getItem('cur');
let mode = localStorage.getItem('mode') || 'short';
let busy = false, status = 'unknown', lastInfo = null;
// save(), cur(), makeChat(), usedThisSession(), buildPrompt(), MODES, init(): unchanged from the old file

function setStatus(s, d) { status = s; UI.setStatus(s, d); }
function pollInfo() { const i = AIChat.info(); if (!i) return; lastInfo = i; UI.setInfo(i); }
setInterval(() => { if (!document.hidden) pollInfo(); }, 2500);

const renderChat = () => UI.chat.render(cur(), SID);
function renderDrawer() {
  UI.drawer.render(chats, curId,
    id => { if (busy) return; curId = id; save(); closeAll(); renderChat(); },
    id => ask('این گفتگو حذف شود؟', 'حذف', () => {
      chats = chats.filter(k => k.id !== id);
      if (!chats.length || !cur()) makeChat();
      save(); renderDrawer(); renderChat();
    }));
}
function renderModes() { UI.settings.renderModes(MODES, mode, k => { mode = k; save(); renderModes(); }); }

function send() {
  const text = UI.composer.value();
  if (!text || busy || status !== 'ready') return;
  const blocked = window.LAB && LAB.beforeSend();
  if (blocked) { ask(blocked, 'باشه', null); return; }
  const c = cur();
  UI.composer.clear();
  const um = { role: 'user', text, sess: SID };
  const m = { role: 'ai', raw: '', fa: '', st: null, sess: SID, mode, maxOut: window.LAB ? LAB.maxOut() : 0 };
  c.msgs.push(um, m);
  if (c.title === 'گفتگوی جدید') c.title = text.slice(0, 40);
  save();
  UI.chat.append(UI.chat.makeUser(um));
  const el = UI.chat.makeAi(); UI.chat.append(el); UI.chat.toBottom();

  busy = true; UI.setBusy(true);
  const t0 = performance.now(); let tFirst = 0, tThink = 0, tEnd = 0, n = 0, raf = 0, lastLive = 0;
  const r = el._r;
  r.wait.textContent = 'مدل پیام را می‌خواند… 0.0s';
  UI.chat.paintAi(el, m, true);
  const timer = setInterval(() => {
    if (!tFirst) r.wait.textContent = 'مدل پیام را می‌خواند… ' + fmt((performance.now() - t0) / 1000) + 's';
  }, 200);
  const repaint = () => { raf = 0; const nb = UI.chat.nearBottom(); UI.chat.paintAi(el, m, true); if (nb) UI.chat.toBottom(); };
  const finish = () => {
    clearInterval(timer); busy = false; UI.setBusy(false);
    UI.chat.paintAi(el, m, false); save(); pollInfo(); UI.chat.toBottom();
  };

  AIChat.send(buildPrompt(text),
    en => { /* same as before: m.raw = en; m.st = {...} */ },
    fa => { m.fa = fa; finish(); },
    tok => {
      const now = performance.now();
      if (!tFirst) tFirst = now;
      n++; m.raw += tok;
      if (!tThink && m.raw.indexOf('</think>') >= 0) tThink = now;
      if (now - lastLive > 300) { lastLive = now; UI.setLive(n / Math.max((now - tFirst) / 1000, 0.2)); }
      if (!raf) raf = requestAnimationFrame(repaint);
    },
    err => { m.err = err; finish(); },
    { maxTokens: window.LAB ? LAB.maxOut() : 0 });
  if (window.LAB) LAB.lastPrompt = buildPrompt(text);
}

// ---- bindings (same ids as the old file) ----
$('#go').onclick = send;
$('#inp').addEventListener('keydown', e => { if (e.key === 'Enter' && e.ctrlKey) send(); });
$('#pick').onclick = () => AIChat.pickModel();
$('#bmenu').addEventListener('click', renderDrawer);
$('#bset').addEventListener('click', renderModes);
$('#bnew').onclick = /* unchanged from the old file */ null;
$('#delall').onclick = /* unchanged */ null;
$('#brep').onclick = openReport;                 // openReport() unchanged, writes into #rep-body
$('#blabtools').addEventListener('click', () => $('#blab').click());   // makes lab.js render when the tab is tapped

AIChat.onStatus = setStatus;
setStatus(AIChat.status());
(function () { const inf = AIChat.info(); if (inf && inf.loadError && AIChat.status() === 'need_model') setStatus('need_model', inf.loadError); })();
renderChat(); renderModes(); pollInfo();
```

دو سطر `$('#bnew').onclick = null` و `$('#delall').onclick = null` فقط جای‌نگهدارند؛ بدنهٔ قبلی‌شان را همان‌طور که بود بگذار.

## ۶. دو ویرایش کوچک در `studio.js`

### الف) صندلی‌های استودیو (اختیاری)

- جایی که نقش‌ها ذخیره می‌شوند (حدود خط ۱۴۷: `roles[role] = sel.value; sv('studio_roles', roles); render();`) این را اضافه کن:

```js
UI.studio.setSeats(Object.fromEntries(Object.keys(roles).map(k => [k, roles[k] ? (getModel(roles[k]) || {}).name || roles[k] : ''])));
```

- و یک بار هنگام شروع (بعد از `let roles = ...`) همان خط را صدا بزن.
- در `onEv` (دریافت‌کنندهٔ رویدادهای `StudioCore.runStudio`) برای `ev.type === 'phase'`:

```js
UI.studio.seatState(ev.ph.role, ev.ph.status);   // 'run' | 'done' | 'error'
```

(در پایان اجرا برای هر چهار نقش `'idle'` بفرست.)

### ب) تب «وب» دیگر داخل استودیو نیست؛ اتاق جدا دارد

۱. در `TABS` ورودی `'web'` را حذف کن و شاخهٔ `if (tab === 'web') {...}` داخل `render()` را هم.
۲. تابع `buildWebBox` و متغیرهای `webFrame`/`webBox` را با این جایگزین کن:

```js
const hasNet = typeof window.SearchBridge !== 'undefined';
const webFrame = $('#web-frame');
// the native bridge answers in the main frame; forward it to the search page
window.onHttpResult = (id, status, text, err) => {
  const w = webFrame.contentWindow;
  if (w && typeof w.onHttpResult === 'function') w.onHttpResult(id, status, text, err);
};
UI.web.init({
  available: hasNet,
  enabled: hasNet && window.SearchBridge.enabled(),
  hosts: hasNet ? window.SearchBridge.hosts() : '',
  src: 'search-tool.html',
  onToggle: on => window.SearchBridge.setEnabled(on)
});
```

۳. `window.WebSearch` را همان‌طور که هست نگه دار. `iframe` با اولین ورود به اتاق «وب» بارگذاری می‌شود، پس `WebSearch.available()` تا آن لحظه `false` است (همان رفتار قبلی).

## ۷. دیدن UI در مرورگر (حالت دمو)

فایل را در مرورگر باز کن. چون `AIChat` وجود ندارد، دمو اجرا می‌شود. با افزودن این‌ها به آدرس مستقیم به یک حالت می‌روی: `#need`، `#loading`، `#ready`، `#empty`، `#error`.

در دمو: دکمهٔ «انتخاب فایل مدل» مراحل کپی و بارگذاری را شبیه‌سازی می‌کند، پیام‌ها استریم می‌شوند و بخش‌های استودیو، آزمایشگاه و گزارش با نمونهٔ کلاس‌های قدیمی (`card2`، `chip`، `kv`، `tt`، …) نشان داده می‌شوند تا پوستهٔ جدیدشان دیده شود.

## ۸. فونت

فونت‌ها از سیستم می‌آیند (چیزی دانلود نمی‌شود). برای فونت اختصاصی، فایل را در `assets/fonts/` بگذار و اول `<style>` اضافه کن:

```css
@font-face { font-family: "Vazirmatn"; src: url("fonts/Vazirmatn-Regular.woff2") format("woff2"); font-weight: 400; }
```

سه متغیر `--sans` (کنترل‌ها)، `--voice` (صدای مدل و عنوان‌ها؛ نسخ/سریف) و `--mono` (اعداد ابزار) در بالای `<style>` هستند.

## ۹. فهرست آزمون پس از اتصال

- [ ] بدون مدل: صفحهٔ ورود با اخگرِ خاکستر و ایستگاه ۱؛ دکمهٔ انتخاب فایل کار می‌کند.
- [ ] هنگام کپی/بارگذاری: ایستگاه ۲، متن مرحله درست (کپی ← بارگذاری) و اخگر در حال افروختن.
- [ ] `ready`: صفحه بسته می‌شود، نوار نوشتن فعال است.
- [ ] خطای بارگذاری (`loadError`): پیام قرمز زیر دکمه و بدون قفل شدن.
- [ ] هنگام تولید: اخگر «فکر»، بعد «سخن»؛ `tok/s` بالای صفحه؛ پایان: برگشت به «آرام».
- [ ] پیام با `<think>`: بلوک جمع‌شونده و زمان تفکر.
- [ ] نوار رم: هشدار (رنگ انار) وقتی رم آزاد کمتر از ۹۰۰MB است.
- [ ] استودیو، آزمایشگاه و گزارش بدون خطای `ReferenceError` باز می‌شوند.
- [ ] دروازهٔ وب بسته: مهر «آفلاین»؛ بعد از روشن کردن: «وب روشن» و جستجو کار می‌کند.
- [ ] تم «شب»، «سپیده» و «خودکار»؛ اندازهٔ متن؛ حرکت کم (`prefers-reduced-motion`) بدون انیمیشن.
